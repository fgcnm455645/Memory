package com.example.memorytest

import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.airbnb.lottie.LottieAnimationView
import com.airbnb.lottie.LottieDrawable

/**
 * Part 0 - star animation test.
 * Plays the ORIGINAL Samsung Memory Lottie file (Intelligence_progress_color)
 * exactly as shipped in the APK. Tap anywhere to play it again.
 */
class MainActivity : AppCompatActivity() {

    private lateinit var bigStar: LottieAnimationView
    private lateinit var smallStar: LottieAnimationView
    private lateinit var loopBtn: TextView
    private lateinit var speedBtn: TextView

    private var loop = false
    private var slow = false

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setBackgroundColor(Color.BLACK)
            setPadding(dp(24), dp(48), dp(24), dp(24))
            setOnClickListener { play() }
        }

        root.addView(label("Tap anywhere to play", 14f, Color.parseColor("#99FFFFFF"), false))

        // Big star (easy to inspect)
        bigStar = star(dp(220))
        root.addView(bigStar, LinearLayout.LayoutParams(dp(220), dp(220)).apply {
            topMargin = dp(40)
        })

        // Small star + text, like the "Analyzing..." row in the Memory list
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        smallStar = star(dp(24))
        row.addView(smallStar, LinearLayout.LayoutParams(dp(24), dp(24)))
        row.addView(label("Analyzing...", 16f, Color.WHITE, true).apply {
            setPadding(dp(8), 0, 0, 0)
        })
        root.addView(row, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.WRAP_CONTENT,
            LinearLayout.LayoutParams.WRAP_CONTENT
        ).apply { topMargin = dp(40) })

        // Buttons
        val buttons = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
        }
        val playBtn = pill("Play") { play() }
        loopBtn = pill("Loop: OFF") {
            loop = !loop
            loopBtn.text = if (loop) "Loop: ON" else "Loop: OFF"
            play()
        }
        speedBtn = pill("Speed: 1x") {
            slow = !slow
            speedBtn.text = if (slow) "Speed: 0.25x" else "Speed: 1x"
            play()
        }
        for (b in listOf(playBtn, loopBtn, speedBtn)) {
            buttons.addView(b, LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply { marginStart = dp(6); marginEnd = dp(6) })
        }
        root.addView(buttons, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.WRAP_CONTENT,
            LinearLayout.LayoutParams.WRAP_CONTENT
        ).apply { topMargin = dp(48) })

        setContentView(root)
        root.post { play() }
    }

    private fun star(sizePx: Int): LottieAnimationView {
        return LottieAnimationView(this).apply {
            setAnimation("intelligence_progress_color.json")
            scaleType = android.widget.ImageView.ScaleType.FIT_CENTER
        }
    }

    private fun play() {
        for (v in listOf(bigStar, smallStar)) {
            v.cancelAnimation()
            v.progress = 0f
            v.repeatCount = if (loop) LottieDrawable.INFINITE else 0
            v.speed = if (slow) 0.25f else 1f
            v.playAnimation()
        }
    }

    private fun label(text: String, sp: Float, color: Int, bold: Boolean): TextView {
        return TextView(this).apply {
            this.text = text
            textSize = sp
            setTextColor(color)
            if (bold) typeface = Typeface.DEFAULT_BOLD
        }
    }

    private fun pill(text: String, onClick: (View) -> Unit): TextView {
        return TextView(this).apply {
            this.text = text
            textSize = 14f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            setPadding(dp(16), dp(10), dp(16), dp(10))
            background = GradientDrawable().apply {
                cornerRadius = dp(24).toFloat()
                setColor(Color.parseColor("#2B2B2D"))
            }
            setOnClickListener(onClick)
        }
    }
}
