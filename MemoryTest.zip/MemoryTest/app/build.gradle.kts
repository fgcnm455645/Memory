plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.example.memorytest"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.example.memorytest"
        minSdk = 26
        targetSdk = 34
        versionCode = 1
        versionName = "0.1-star-test"
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
}

dependencies {
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("com.airbnb.android:lottie:6.4.1")
}
