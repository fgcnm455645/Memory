package com.aiselect.app

import android.content.Context
import android.graphics.BlurMaskFilter
import android.graphics.Canvas
import android.graphics.LinearGradient
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.SweepGradient
import android.view.View
import kotlin.math.cos
import kotlin.math.sin

/**
 * Entry effects: the pastel color wash and the glowing rim around the screen edge.
 * The rim colors (yellow, mint, blue, lavender) slowly travel around the screen.
 */
class RimView(context: Context) : View(context) {

    var rimAlpha: Float = 0f
        set(v) {
            field = v
            invalidate()
        }
    var washAlpha: Float = 0f
        set(v) {
            field = v
            invalidate()
        }
    var washPhase: Float = 0f
        set(v) {
            field = v
            invalidate()
        }
    var rimPhase: Float = 0f
        set(v) {
            field = v
            invalidate()
        }

    private val bandPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }
    private val glowPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }
    private val washPaint = Paint()
    private val path = Path()
    private val m = Matrix()
    private var sweep: SweepGradient? = null

    private val rimColors = intArrayOf(
        0xFFECF58C.toInt(), 0xFFA6EBD0.toInt(), 0xFF9CB8FF.toInt(), 0xFFBCA8FF.toInt(),
        0xFF9CB8FF.toInt(), 0xFFA6EBD0.toInt(), 0xFFECF58C.toInt()
    )
    private val washColors = intArrayOf(
        0xFFF4F4A0.toInt(), 0xFFA5E6D2.toInt(), 0xFF9DB4FF.toInt(), 0xFFC7A6FF.toInt()
    )

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        sweep = SweepGradient(w / 2f, h / 2f, rimColors, null)
        bandPaint.shader = sweep
        glowPaint.shader = sweep
        bandPaint.strokeWidth = context.u(40f)
        glowPaint.strokeWidth = context.u(46f)
        glowPaint.maskFilter = BlurMaskFilter(context.u(38f), BlurMaskFilter.Blur.NORMAL)
        path.reset()
        val r = context.u(95f)
        path.addRoundRect(RectF(0f, 0f, w.toFloat(), h.toFloat()), r, r, Path.Direction.CW)
    }

    override fun onDraw(c: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        if (washAlpha > 0.001f) {
            val a = washPhase * 6.2831855f
            val d = h * 0.6f
            val cx = w / 2f
            val cy = h / 2f
            washPaint.shader = LinearGradient(
                cx - cos(a) * d * 0.5f, cy - sin(a) * d, cx + cos(a) * d * 0.5f, cy + sin(a) * d,
                washColors, null, Shader.TileMode.CLAMP
            )
            washPaint.alpha = (washAlpha.coerceIn(0f, 1f) * 255).toInt()
            c.drawRect(0f, 0f, w, h, washPaint)
        }
        if (rimAlpha > 0.001f) {
            m.setRotate(rimPhase, w / 2f, h / 2f)
            sweep?.setLocalMatrix(m)
            val k = rimAlpha.coerceIn(0f, 1f)
            glowPaint.alpha = (0.85f * k * 255).toInt()
            c.drawPath(path, glowPaint)
            bandPaint.alpha = (k * 255).toInt()
            c.drawPath(path, bandPaint)
        }
    }
}
