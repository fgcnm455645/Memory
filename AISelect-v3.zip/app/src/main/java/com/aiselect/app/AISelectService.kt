package com.aiselect.app

import android.accessibilityservice.AccessibilityService
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.graphics.Rect
import android.graphics.drawable.GradientDrawable
import android.os.Handler
import android.os.Looper
import android.view.Display
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.Toast

/**
 * Takes the screenshot (no MediaProjection prompt) and opens [SelectActivity].
 * It only runs when you trigger it; it never reads or stores anything from the screen.
 */
class AISelectService : AccessibilityService() {

    companion object {
        @Volatile
        var instance: AISelectService? = null
    }

    private val handler = Handler(Looper.getMainLooper())
    private var busy = false
    private var gif: GifRecorder? = null

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
    }

    override fun onUnbind(intent: Intent?): Boolean {
        instance = null
        return super.onUnbind(intent)
    }

    override fun onDestroy() {
        instance = null
        super.onDestroy()
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}

    override fun onInterrupt() {}

    fun captureDelayed(delayMs: Long) {
        handler.postDelayed({ capture() }, delayMs)
    }

    /** Screenshot as a software bitmap, or null on failure. Callback runs on the main thread. */
    fun takeShot(cb: (Bitmap?) -> Unit) {
        takeScreenshot(Display.DEFAULT_DISPLAY, mainExecutor, object : TakeScreenshotCallback {
            override fun onSuccess(result: ScreenshotResult) {
                var soft: Bitmap? = null
                try {
                    val buffer = result.hardwareBuffer
                    val hw = Bitmap.wrapHardwareBuffer(buffer, result.colorSpace)
                    soft = hw?.copy(Bitmap.Config.ARGB_8888, false)
                    hw?.recycle()
                    buffer.close()
                } catch (e: Exception) {
                    soft = null
                }
                cb(soft)
            }

            override fun onFailure(errorCode: Int) {
                cb(null)
            }
        })
    }

    private fun capture() {
        if (busy) return
        busy = true
        takeShot { bmp ->
            busy = false
            if (bmp != null) {
                ShotHolder.bitmap = bmp
                val i = Intent(this, SelectActivity::class.java)
                i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_NO_ANIMATION)
                startActivity(i)
            } else {
                Toast.makeText(this, "Screenshot failed", Toast.LENGTH_SHORT).show()
            }
        }
    }

    // ---------- Pin ----------

    fun pin(bmp: Bitmap, x: Int, y: Int) {
        val wm = getSystemService(WINDOW_SERVICE) as WindowManager
        val box = FrameLayout(this)
        val iv = ImageView(this)
        iv.setImageBitmap(bmp)
        box.addView(iv, FrameLayout.LayoutParams(bmp.width, bmp.height))
        box.background = GradientDrawable().apply {
            setStroke(ui(4f), 0xE6FFFFFF.toInt())
            setColor(0x00000000)
        }
        box.elevation = ui(12f).toFloat()
        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        )
        lp.gravity = Gravity.TOP or Gravity.START
        lp.x = x
        lp.y = y

        val close = CloseButton(this)
        val cs = ui(64f)
        val cl = FrameLayout.LayoutParams(cs, cs, Gravity.TOP or Gravity.END)
        cl.topMargin = ui(10f)
        cl.marginEnd = ui(10f)
        box.addView(close, cl)
        close.setOnClickListener {
            try {
                wm.removeView(box)
            } catch (e: Exception) {
            }
        }

        var dx = 0f
        var dy = 0f
        var sx = 0
        var sy = 0
        box.setOnTouchListener { _, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    dx = e.rawX
                    dy = e.rawY
                    sx = lp.x
                    sy = lp.y
                }
                MotionEvent.ACTION_MOVE -> {
                    lp.x = sx + (e.rawX - dx).toInt()
                    lp.y = sy + (e.rawY - dy).toInt()
                    try {
                        wm.updateViewLayout(box, lp)
                    } catch (ex: Exception) {
                    }
                }
            }
            true
        }
        wm.addView(box, lp)
    }

    // ---------- GIF ----------

    fun startGif(region: Rect) {
        gif?.dismiss()
        val g = GifRecorder(this, region)
        gif = g
        g.show()
    }

    fun gifFinished() {
        gif = null
    }
}
