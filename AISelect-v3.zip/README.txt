AI Select v3 (personal use) - Android 13+, tuned for Android 17 / One UI 9

v3 changes:
- Small Galaxy AI sparkles in the screen center.
- Light blur + tint (not heavy blur), color wash, rotating pastel rim glow.
- Selection: rounded square (80px corners), thin outline, outward light shadow,
  four thick tinted corner arcs.
- Thicker glowing stroke with dark center line and dust.
- Chip row: [Extract text circle] [Set as wallpaper] [Create GIF] [3-dot menu].
  X turns into 3 dots after selecting.
- App icon: the original frame/brackets icon.
Setup: Settings > Accessibility > Installed apps > AI Select > on.
