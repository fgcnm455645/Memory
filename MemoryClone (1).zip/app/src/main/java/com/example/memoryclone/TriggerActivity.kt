package com.example.memoryclone

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.widget.Toast

/**
 * Invisible "Save to Memory" action. Used by the app-icon shortcut, the Quick Settings tile
 * and the home-screen icon. It finishes immediately so the screen underneath is captured.
 */
class TriggerActivity : Activity() {

    companion object {
        const val EXTRA_DELAY = "delay"
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val s = CaptureService.instance
        if (s != null) {
            s.capture(intent.getLongExtra(EXTRA_DELAY, 0L), true)
        } else {
            Toast.makeText(this, "Turn on Memory in Accessibility settings first", Toast.LENGTH_LONG).show()
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        }
        finish()
        overridePendingTransition(0, 0)
    }
}
