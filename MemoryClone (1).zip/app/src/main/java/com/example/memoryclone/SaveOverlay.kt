package com.example.memoryclone

import android.accessibilityservice.AccessibilityService
import android.animation.Animator
import android.animation.AnimatorListenerAdapter
import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.PixelFormat
import android.graphics.RadialGradient
import android.graphics.RenderEffect
import android.graphics.RuntimeShader
import android.graphics.Shader
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.view.ContextThemeWrapper
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.view.animation.LinearInterpolator
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.TextView
import com.airbnb.lottie.LottieAnimationView
import java.util.Random

/**
 * Full-screen overlay that plays the "Save to Memory" animation over whatever is on screen.
 *
 * Original Samsung parts (unchanged): wave shader, slit-glow + particles shader, app icon Lottie.
 * Measured from the original screen recording: colours, opacity curves, timing, icon position.
 * All times below are in milliseconds from the start of the wave.
 */
class SaveOverlay(
    private val service: AccessibilityService,
    private val shot: Bitmap,
    private val onDone: () -> Unit
) {
    companion object {
        const val WAVE_MS = 670f          // shader progress 0..1, linear (fitted frame by frame)
        const val TINT_START = 460f       // violet veil starts
        const val TINT_PEAK = 1160f       // fully in
        const val TINT_HOLD_END = 1510f   // starts fading
        const val TINT_END = 2760f        // gone
        const val GLOW_IN_START = 1210f   // violet glow around the icon
        const val GLOW_IN_END = 1510f
        const val GLOW_OUT_START = 2610f
        const val GLOW_OUT_END = 3310f
        const val ICON_START = 1260f      // icon Lottie (2 s long)
        const val ICON_MS = 2000f
        const val TOTAL_MS = 3400f
        const val SLIT_AMOUNT = 0.18f     // strength of the original slit/particle shader
    }

    private val ctx = ContextThemeWrapper(service, R.style.Theme_Memory)
    private val wm = service.getSystemService(Context.WINDOW_SERVICE) as WindowManager
    private val root = FrameLayout(ctx)
    private val image = ImageView(ctx)
    private val tint = View(ctx)
    private val dome = DomeView(ctx)
    private val slit = SlitView(ctx)
    private val icon = LottieAnimationView(ctx)
    private val caption = TextView(ctx)
    private var shader: RuntimeShader? = null
    private var anim: ValueAnimator? = null
    private var added = false
    private var w = 0
    private var h = 0

    private fun seg(ms: Float, a: Float, b: Float): Float = ((ms - a) / (b - a)).coerceIn(0f, 1f)

    private fun argb(a: Float, r: Int, g: Int, b: Int): Int =
        Color.argb((a * 255f).toInt().coerceIn(0, 255), r, g, b)

    fun show() {
        try {
            val b = wm.maximumWindowMetrics.bounds
            w = b.width()
            h = b.height()

            image.scaleType = ImageView.ScaleType.FIT_XY
            image.setImageBitmap(shot)
            root.addView(image, FrameLayout.LayoutParams(-1, -1))

            // Violet veil: vertical gradient (colours + opacity measured from the original)
            tint.background = GradientDrawable(
                GradientDrawable.Orientation.TOP_BOTTOM,
                intArrayOf(0xFF000000.toInt(), 0xFF000000.toInt())
            ).apply {
                setColors(
                    intArrayOf(
                        argb(.54f, 112, 108, 240), argb(.54f, 111, 108, 239), argb(.55f, 97, 106, 232),
                        argb(.55f, 81, 104, 224), argb(.52f, 68, 103, 216), argb(.39f, 66, 100, 218),
                        argb(.28f, 68, 103, 222), argb(.20f, 70, 104, 224), argb(.12f, 70, 104, 224)
                    ),
                    floatArrayOf(0f, .18f, .28f, .40f, .52f, .64f, .75f, .86f, 1f)
                )
            }
            tint.alpha = 0f
            root.addView(tint, FrameLayout.LayoutParams(-1, -1))

            // Wide violet glow around the icon
            dome.alpha = 0f
            root.addView(dome, FrameLayout.LayoutParams(-1, -1))

            // Original slit glow + particles (only the bottom part of the screen)
            val slitTop = (h * 0.66f).toInt()
            slit.setup(w, h, slitTop)
            root.addView(slit, FrameLayout.LayoutParams(-1, h - slitTop, Gravity.TOP).apply {
                topMargin = slitTop
            })

            // Icon: canvas centre sits 0.127 canvas-heights below the white square centre
            val iconSize = (w * 0.29f).toInt()
            val iconCenterY = h * 0.877f
            icon.setImageAssetsFolder("images/")
            icon.setAnimation("memory_app_icon.json")
            icon.progress = 0f
            icon.visibility = View.INVISIBLE
            root.addView(icon, FrameLayout.LayoutParams(iconSize, iconSize, Gravity.TOP or Gravity.CENTER_HORIZONTAL).apply {
                topMargin = (iconCenterY - iconSize / 2f).toInt()
            })

            caption.text = "Saved to Memory"
            caption.textSize = 13f
            caption.setTextColor(Color.WHITE)
            caption.typeface = Typeface.DEFAULT_BOLD
            caption.setShadowLayer(6f, 0f, 1f, 0x55000000)
            caption.alpha = 0f
            root.addView(caption, FrameLayout.LayoutParams(-2, -2, Gravity.TOP or Gravity.CENTER_HORIZONTAL).apply {
                topMargin = (h * 0.947f - 26f).toInt()
            })

            val lp = WindowManager.LayoutParams(
                w, h,
                WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                        WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                        WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                        WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS or
                        WindowManager.LayoutParams.FLAG_HARDWARE_ACCELERATED,
                PixelFormat.TRANSLUCENT
            ).apply {
                gravity = Gravity.TOP or Gravity.START
                layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_ALWAYS
            }
            wm.addView(root, lp)
            added = true

            shader = try { RuntimeShader(WaveShader.SRC) } catch (_: Throwable) { null }

            anim = ValueAnimator.ofFloat(0f, TOTAL_MS).apply {
                duration = TOTAL_MS.toLong()
                interpolator = LinearInterpolator()
                addUpdateListener { update(it.animatedValue as Float) }
                addListener(object : AnimatorListenerAdapter() {
                    override fun onAnimationEnd(animation: Animator) = finish()
                })
                start()
            }
        } catch (_: Throwable) {
            finish()
        }
    }

    private fun update(ms: Float) {
        // 1) the wave (original shader)
        val p = (ms / WAVE_MS).coerceIn(0f, 1f)
        val sh = shader
        if (sh == null || p <= 0f || p >= 1f) {
            image.setRenderEffect(null)
        } else {
            try {
                sh.setFloatUniform("uRes", w.toFloat(), h.toFloat())
                sh.setFloatUniform("uProgress", p)
                image.setRenderEffect(RenderEffect.createRuntimeShaderEffect(sh, "content"))
            } catch (_: Throwable) {
                shader = null
                image.setRenderEffect(null)
            }
        }

        // 2) violet veil: linear in, hold, linear out
        tint.alpha = seg(ms, TINT_START, TINT_PEAK) * (1f - seg(ms, TINT_HOLD_END, TINT_END))

        // 3) glow around the icon
        val glow = seg(ms, GLOW_IN_START, GLOW_IN_END).let { it * it * (3f - 2f * it) } *
                (1f - seg(ms, GLOW_OUT_START, GLOW_OUT_END))
        dome.alpha = glow
        slit.update(glow * SLIT_AMOUNT, glow, (ms - ICON_START) / 1000f)

        // 4) icon (original Lottie, also drives its own slide in / out) and caption
        val inIcon = ms >= ICON_START && ms < ICON_START + ICON_MS
        icon.visibility = if (inIcon) View.VISIBLE else View.INVISIBLE
        icon.progress = seg(ms, ICON_START, ICON_START + ICON_MS)
        caption.alpha = seg(ms, ICON_START + 60f, ICON_START + 300f) * (1f - seg(ms, 2850f, 3250f))
    }

    private fun finish() {
        anim = null
        if (added) {
            try { wm.removeViewImmediate(root) } catch (_: Throwable) {}
            added = false
        }
        onDone()
    }

    /** Soft violet ellipse around the icon (profile measured from the original). */
    private class DomeView(context: Context) : View(context) {
        private val paint = Paint(Paint.ANTI_ALIAS_FLAG)

        init {
            paint.shader = RadialGradient(
                0f, 0f, 1f,
                intArrayOf(
                    Color.argb(158, 170, 125, 242), Color.argb(153, 170, 125, 242),
                    Color.argb(102, 170, 125, 242), Color.argb(54, 170, 125, 242),
                    Color.argb(0, 170, 125, 242)
                ),
                floatArrayOf(0f, .34f, .56f, .78f, 1f),
                Shader.TileMode.CLAMP
            )
        }

        override fun onDraw(canvas: Canvas) {
            val cx = width * 0.5f
            val cy = height * 0.895f
            val rx = width * 0.5f
            // upper half taller than lower half
            canvas.save()
            canvas.clipRect(0f, 0f, width.toFloat(), cy)
            canvas.translate(cx, cy)
            canvas.scale(rx, height * 0.22f)
            canvas.drawCircle(0f, 0f, 1f, paint)
            canvas.restore()
            canvas.save()
            canvas.clipRect(0f, cy, width.toFloat(), height.toFloat())
            canvas.translate(cx, cy)
            canvas.scale(rx, height * 0.16f)
            canvas.drawCircle(0f, 0f, 1f, paint)
            canvas.restore()
        }
    }

    /** Runs the ORIGINAL slit-glow + particle shader on the bottom strip of the screen. */
    private class SlitView(context: Context) : View(context) {
        private var shader: RuntimeShader? = null
        private val paint = Paint()
        private var fullW = 0f
        private var fullH = 0f
        private var top = 0f
        private val tracks = FloatArray(36)
        private val seeds = FloatArray(56)
        private var time = 0f
        private var on = false

        fun setup(w: Int, h: Int, topPx: Int) {
            fullW = w.toFloat()
            fullH = h.toFloat()
            top = topPx.toFloat()
            val rnd = Random(7)
            for (i in seeds.indices) seeds[i] = rnd.nextFloat()
            shader = try { RuntimeShader(WaveShader.SLIT) } catch (_: Throwable) { null }
            paint.shader = shader
        }

        fun update(slitAmount: Float, particleAmount: Float, t: Float) {
            on = slitAmount > 0.002f && shader != null
            time = t
            tracks.fill(0f)
            tracks[0] = 1f; tracks[1] = 1f; tracks[2] = slitAmount
            for (i in 1..4) { tracks[i * 4 + 1] = 1f; tracks[i * 4 + 2] = slitAmount }
            tracks[5 * 4 + 2] = particleAmount
            visibility = if (on) VISIBLE else INVISIBLE
            if (on) invalidate()
        }

        override fun onDraw(canvas: Canvas) {
            val sh = shader ?: return
            if (!on) return
            try {
                sh.setFloatUniform("iResolution", fullW, fullH)
                sh.setFloatUniform("uOrigin", 0f, -top)
                sh.setFloatUniform("iTime", time.coerceAtLeast(0f))
                sh.setFloatUniform("uTracks", tracks)
                sh.setFloatUniform("uParticleSeeds", seeds)
                sh.setFloatUniform("uSlitAlpha", 1f)
                sh.setFloatUniform("uParticles", 1f)
                canvas.drawRect(0f, 0f, width.toFloat(), height.toFloat(), paint)
            } catch (_: Throwable) {
                shader = null
            }
        }
    }
}
