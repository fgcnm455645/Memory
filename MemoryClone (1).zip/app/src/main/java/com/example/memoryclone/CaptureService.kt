package com.example.memoryclone

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.AccessibilityService.ScreenshotResult
import android.accessibilityservice.AccessibilityService.TakeScreenshotCallback
import android.app.KeyguardManager
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.ColorSpace
import android.hardware.HardwareBuffer
import android.os.Handler
import android.os.Looper
import android.os.PowerManager
import android.view.Display
import android.view.accessibility.AccessibilityEvent
import android.widget.Toast
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import java.io.FileOutputStream
import java.util.concurrent.Executors

/**
 * Accessibility service: takes the screenshot, plays the save animation over the screen,
 * stores the memory and analyses it (app name + readable Latin text).
 *
 * Pre-capture: while the screen is on and unlocked, the service keeps the latest screen frame in
 * memory (one frame about every 1.2 s, never saved). When the save action is started by launching
 * an activity (side key routine / shortcut), the system is already animating the app away by the
 * time we run, so the clean pre-captured frame is used instead of a fresh one.
 */
class CaptureService : AccessibilityService() {

    companion object {
        @Volatile
        var instance: CaptureService? = null
        private const val PRE_INTERVAL = 1200L
        private const val CACHE_MAX_AGE = 2500L
    }

    private val main = Handler(Looper.getMainLooper())
    private val io = Executors.newSingleThreadExecutor()
    private var lastPkg = ""
    private var overlay: SaveOverlay? = null

    private var cacheBuffer: HardwareBuffer? = null
    private var cacheSpace: ColorSpace? = null
    private var cacheAt = 0L
    private var cachePkg = ""
    private var busyUntil = 0L

    private val preLoop = object : Runnable {
        override fun run() {
            try { preCapture() } catch (_: Throwable) {}
            main.postDelayed(this, PRE_INTERVAL)
        }
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
        main.removeCallbacks(preLoop)
        main.postDelayed(preLoop, 1500)
    }

    override fun onUnbind(intent: Intent?): Boolean {
        instance = null
        main.removeCallbacks(preLoop)
        closeCache()
        return super.onUnbind(intent)
    }

    override fun onDestroy() {
        instance = null
        main.removeCallbacks(preLoop)
        closeCache()
        super.onDestroy()
    }

    override fun onInterrupt() {}

    override fun onAccessibilityEvent(e: AccessibilityEvent?) {
        if (e == null || e.eventType != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) return
        val pkg = e.packageName?.toString() ?: return
        if (pkg == packageName || pkg == "com.android.systemui" || pkg == "android" ||
            pkg.contains("inputmethod")
        ) return
        lastPkg = pkg
    }

    // ---------------------------------------------------------------- pre-capture cache

    private fun closeCache() {
        try { cacheBuffer?.close() } catch (_: Throwable) {}
        cacheBuffer = null
    }

    private fun preCapture() {
        val pm = getSystemService(PowerManager::class.java)
        val km = getSystemService(KeyguardManager::class.java)
        if (overlay != null || !pm.isInteractive || km.isKeyguardLocked) return
        if (System.currentTimeMillis() < busyUntil) return
        val pkg = lastPkg
        takeScreenshot(Display.DEFAULT_DISPLAY, mainExecutor, object : TakeScreenshotCallback {
            override fun onSuccess(result: ScreenshotResult) {
                if (overlay != null || System.currentTimeMillis() < busyUntil) {
                    try { result.hardwareBuffer.close() } catch (_: Throwable) {}
                    return
                }
                closeCache()
                cacheBuffer = result.hardwareBuffer
                cacheSpace = result.colorSpace
                cacheAt = System.currentTimeMillis()
                cachePkg = pkg
            }

            override fun onFailure(errorCode: Int) {}
        })
    }

    // ---------------------------------------------------------------- capture

    /**
     * Called by the save action.
     * useCache = true: use the latest pre-captured frame (when the trigger launched an activity).
     * useCache = false: take a fresh screenshot after delayMs (tile, test button).
     */
    fun capture(delayMs: Long = 50, useCache: Boolean = false) {
        val target = if (useCache && cacheBuffer != null) cachePkg else lastPkg
        busyUntil = System.currentTimeMillis() + delayMs + 4000
        main.postDelayed({ doCapture(useCache) }, delayMs)
        // Safety net: if the system sent the user to the home screen, put the app back.
        main.postDelayed({ restoreApp(target) }, delayMs + 1000)
    }

    private fun homePackages(): Set<String> {
        val set = mutableSetOf("com.sec.android.app.launcher")
        try {
            val i = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME)
            packageManager.queryIntentActivities(i, 0).forEach { set.add(it.activityInfo.packageName) }
        } catch (_: Throwable) {
        }
        return set
    }

    private fun restoreApp(target: String) {
        if (target.isEmpty() || target == packageName) return
        val homes = homePackages()
        if (target in homes) return
        if (lastPkg in homes) {
            try {
                packageManager.getLaunchIntentForPackage(target)?.let {
                    it.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    startActivity(it)
                }
            } catch (_: Throwable) {
            }
        }
    }

    private fun toast(msg: String) {
        Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()
    }

    private fun doCapture(useCache: Boolean) {
        if (overlay != null) return
        if (useCache) {
            val buf = cacheBuffer
            if (buf != null && System.currentTimeMillis() - cacheAt <= CACHE_MAX_AGE) {
                try {
                    val hw = Bitmap.wrapHardwareBuffer(buf, cacheSpace)
                    val soft = hw?.copy(Bitmap.Config.ARGB_8888, false)
                    val pkg = cachePkg
                    closeCache()
                    if (soft != null) {
                        onShot(soft, pkg)
                        return
                    }
                } catch (_: Throwable) {
                }
            }
        }
        freshCapture()
    }

    private fun freshCapture() {
        val pkgAtCapture = lastPkg
        takeScreenshot(Display.DEFAULT_DISPLAY, mainExecutor, object : TakeScreenshotCallback {
            override fun onSuccess(result: ScreenshotResult) {
                try {
                    val hw = Bitmap.wrapHardwareBuffer(result.hardwareBuffer, result.colorSpace)
                    val soft = hw?.copy(Bitmap.Config.ARGB_8888, false)
                    result.hardwareBuffer.close()
                    if (soft == null) {
                        toast("Screenshot failed")
                        return
                    }
                    onShot(soft, pkgAtCapture)
                } catch (e: Throwable) {
                    toast("Screenshot error: " + e.javaClass.simpleName)
                }
            }

            override fun onFailure(errorCode: Int) {
                toast("Screenshot failed (code $errorCode). Try again in a second.")
            }
        })
    }

    private fun appLabel(pkg: String): String {
        if (pkg.isEmpty()) return "Screenshot"
        return try {
            packageManager.getApplicationLabel(packageManager.getApplicationInfo(pkg, 0)).toString()
        } catch (_: Throwable) {
            pkg
        }
    }

    private fun onShot(bmp: Bitmap, pkg: String) {
        val id = System.currentTimeMillis()
        Store.add(this, Memory(id, "Analyzing...", "", pkg, true))

        val o = SaveOverlay(this, bmp) { overlay = null }
        overlay = o
        o.show()

        io.execute {
            try {
                FileOutputStream(Store.fullFile(this, id)).use { bmp.compress(Bitmap.CompressFormat.JPEG, 90, it) }
                val tw = 360
                val th = (tw.toFloat() * bmp.height / bmp.width).toInt()
                val thumb = Bitmap.createScaledBitmap(bmp, tw, th, true)
                FileOutputStream(Store.thumbFile(this, id)).use { thumb.compress(Bitmap.CompressFormat.JPEG, 85, it) }
            } catch (_: Throwable) {
            }
            main.post { analyze(bmp, id, pkg) }
        }
    }

    private fun analyze(bmp: Bitmap, id: Long, pkg: String) {
        val title = appLabel(pkg)
        val rec = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
        rec.process(InputImage.fromBitmap(bmp, 0))
            .addOnSuccessListener { text ->
                val lines = text.textBlocks.flatMap { b -> b.lines.map { it.text.trim() } }
                    .filter { it.length >= 4 && it.any { c -> c.isLetter() } }
                val sb = StringBuilder()
                for (l in lines) {
                    if (sb.length >= 130) break
                    if (sb.isNotEmpty()) sb.append(" · ")
                    sb.append(l)
                }
                val desc = if (sb.isEmpty()) "Screenshot of $title" else sb.toString().take(160)
                Store.finishAnalysis(this, id, title, desc)
                rec.close()
            }
            .addOnFailureListener {
                Store.finishAnalysis(this, id, title, "Screenshot of $title")
                rec.close()
            }
    }
}
