plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.example.memoryclone"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.example.memoryclone"
        minSdk = 33
        targetSdk = 34
        versionCode = 1
        versionName = "1.5-precapture"
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
}

dependencies {
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("com.airbnb.android:lottie:6.4.1")
    implementation("com.google.mlkit:text-recognition:16.0.1")
}
