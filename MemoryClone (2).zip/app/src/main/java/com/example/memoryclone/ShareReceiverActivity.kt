package com.example.memoryclone

import android.app.Activity
import android.content.Intent
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Bundle
import android.widget.Toast

/** "Share > Memory": saves shared text or images as memories. */
class ShareReceiverActivity : Activity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        try {
            handle(intent)
        } catch (_: Throwable) {
            Toast.makeText(this, "Couldn't save that", Toast.LENGTH_SHORT).show()
        }
        finish()
        overridePendingTransition(0, 0)
    }

    private fun handle(i: Intent) {
        val uri: Uri? = i.getParcelableExtra(Intent.EXTRA_STREAM, Uri::class.java)
        val txt = i.getStringExtra(Intent.EXTRA_TEXT)
        val id = System.currentTimeMillis()
        if (uri != null) {
            val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
            var sample = 1
            while (bounds.outWidth / sample > 2400 || bounds.outHeight / sample > 2400) sample *= 2
            val opts = BitmapFactory.Options().apply { inSampleSize = sample }
            val bmp = contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, opts) }
            if (bmp != null) {
                Store.saveShot(this, id, bmp)
                Store.add(this, Memory(id, "Analyzing...", "", packageName, true, "image"))
                Analyzer.analyze(applicationContext, bmp, id, "Memory")
                Toast.makeText(this, "Saved to Memory", Toast.LENGTH_SHORT).show()
            }
        } else if (!txt.isNullOrBlank()) {
            val t = txt.trim()
            Store.add(this, Memory(id, t.lines().first().take(40), t, packageName, false, "text"))
            Toast.makeText(this, "Saved to Memory", Toast.LENGTH_SHORT).show()
        }
    }
}
