package com.example.memoryclone

import android.content.Intent
import android.content.pm.ShortcutInfo
import android.content.pm.ShortcutManager
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.Icon
import android.os.Bundle
import android.provider.Settings
import android.util.TypedValue
import android.view.Gravity
import android.view.View
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.WindowCompat
import kotlin.math.roundToInt

/**
 * Settings page (rows copied from the original Memory settings: AI language, Swipe to save,
 * Voice note shortcut, Trash, Privacy) plus the controls that make the save action work here.
 */
class SettingsActivity : AppCompatActivity() {

    private lateinit var sc: Scale
    private lateinit var col: LinearLayout
    private lateinit var serviceValue: TextView
    private val prefs by lazy { getSharedPreferences("settings", MODE_PRIVATE) }

    private fun text(s: String, size: Float, bold: Boolean, color: Int): TextView = TextView(this).apply {
        text = s
        setTextSize(TypedValue.COMPLEX_UNIT_PX, sc.f(size))
        setTextColor(color)
        includeFontPadding = false
        typeface = if (bold) Typeface.DEFAULT_BOLD else Typeface.DEFAULT
    }

    private fun card(): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        background = GradientDrawable().apply { setColor(0xFF161616.toInt()); cornerRadius = sc.f(56f) }
    }

    private fun row(card: LinearLayout, title: String, desc: String?, onClick: (() -> Unit)?, switchKey: String?): TextView? {
        val r = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(sc.i(56f), sc.i(36f), sc.i(56f), sc.i(36f))
        }
        val tx = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        tx.addView(text(title, 46f, false, Color.WHITE))
        var value: TextView? = null
        if (desc != null) {
            value = text(desc, 36f, false, 0xFFB5B5B5.toInt()).apply { setPadding(0, sc.i(10f), 0, 0) }
            tx.addView(value)
        }
        r.addView(tx, LinearLayout.LayoutParams(0, -2, 1f))
        if (switchKey != null) {
            val sw = Switch(this).apply {
                isChecked = prefs.getBoolean(switchKey, true)
                setOnCheckedChangeListener { _, on -> prefs.edit().putBoolean(switchKey, on).apply() }
            }
            r.addView(sw)
            r.setOnClickListener { sw.toggle() }
        } else if (onClick != null) {
            r.setOnClickListener { onClick() }
        }
        card.addView(r)
        return value
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        sc = Scale(this)
        WindowCompat.setDecorFitsSystemWindows(window, false)
        window.statusBarColor = Color.TRANSPARENT
        window.navigationBarColor = Color.TRANSPARENT

        col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(sc.i(32f), sc.i(150f), sc.i(32f), sc.i(120f))
        }

        // top bar: back chevron + title
        val bar = FrameLayout(this)
        val back = ChevronView(this, sc).apply { rotation = 180f }
        bar.addView(back, FrameLayout.LayoutParams(sc.i(120f), sc.i(120f)).apply { leftMargin = sc.i(0f) })
        back.setOnClickListener { finish() }
        val title = text("Settings", 56f, true, Color.WHITE)
        bar.addView(title, FrameLayout.LayoutParams(-2, sc.i(120f)).apply { leftMargin = sc.i(130f) })
        title.gravity = Gravity.CENTER_VERTICAL
        col.addView(bar, LinearLayout.LayoutParams(-1, sc.i(120f)))

        // ---- Save screen (makes the save action work)
        col.addView(text("Save screen", 36f, false, 0xFFB5B5B5.toInt()).apply { setPadding(sc.i(24f), sc.i(60f), 0, sc.i(20f)) })
        val c0 = card()
        serviceValue = row(c0, "Screen capture service", "", { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }, null)!!
        row(c0, "Test: save the screen in 3 seconds", "Go to any app and wait", {
            val s = CaptureService.instance
            if (s == null) {
                Toast.makeText(this, "Turn on the screen capture service first", Toast.LENGTH_LONG).show()
            } else {
                Toast.makeText(this, "Saving the screen in 3 seconds...", Toast.LENGTH_SHORT).show()
                moveTaskToBack(true)
                s.capture(3000)
            }
        }, null)
        row(c0, "Add \"Save to Memory\" to home screen", "Also in Quick Settings, and in Modes and Routines", {
            val sm = getSystemService(ShortcutManager::class.java)
            if (sm != null && sm.isRequestPinShortcutSupported) {
                val info = ShortcutInfo.Builder(this, "save_to_memory_pin")
                    .setShortLabel("Save to Memory")
                    .setIcon(Icon.createWithResource(this, R.drawable.ic_memory))
                    .setIntent(Intent(this, TriggerActivity::class.java).setAction(Intent.ACTION_VIEW))
                    .build()
                sm.requestPinShortcut(info, null)
            } else {
                Toast.makeText(this, "Your launcher can't add this shortcut", Toast.LENGTH_LONG).show()
            }
        }, null)
        col.addView(c0)

        // ---- the rows of the original settings page
        col.addView(text("Memory", 36f, false, 0xFFB5B5B5.toInt()).apply { setPadding(sc.i(24f), sc.i(60f), 0, sc.i(20f)) })
        val c1 = card()
        row(c1, "AI language", "English", null, null)
        row(c1, "Swipe to save", "Swipe down with three fingers to add a screen to Memory.", null, "swipe_to_save")
        row(c1, "Voice note shortcut", "Press the Side and Volume up buttons at the same time to start a voice note.", null, "voice_shortcut")
        row(c1, "Trash", "Keep deleted memories for 30 days.", null, "trash")
        col.addView(c1)

        col.addView(text("Privacy", 36f, false, 0xFFB5B5B5.toInt()).apply { setPadding(sc.i(24f), sc.i(60f), 0, sc.i(20f)) })
        val c2 = card()
        row(c2, "Privacy Notice", null, { Toast.makeText(this, "Everything stays on this phone.", Toast.LENGTH_SHORT).show() }, null)
        row(c2, "Permissions", null, {
            startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS).setData(android.net.Uri.parse("package:$packageName")))
        }, null)
        col.addView(c2)

        setContentView(ScrollView(this).apply {
            setBackgroundColor(Color.BLACK)
            isVerticalScrollBarEnabled = false
            addView(col)
        })
    }

    override fun onResume() {
        super.onResume()
        serviceValue.text = if (CaptureService.instance != null) "On" else "Off - tap to turn it on in Accessibility"
    }
}
