package com.example.memoryclone

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.view.View
import kotlin.math.roundToInt

/** Everything is laid out in the pixel coordinates of a 1080 px wide screen and scaled to the real width. */
class Scale(ctx: Context) {
    val s = ctx.resources.displayMetrics.widthPixels / 1080f
    fun f(v: Float): Float = v * s
    fun i(v: Float): Int = (v * s).roundToInt()
}

/** The "+" of the toolbar: 46 px wide, 4.5 px strokes, white. */
class PlusView(ctx: Context, private val sc: Scale) : View(ctx) {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        strokeWidth = sc.f(4.5f)
        style = Paint.Style.STROKE
    }

    override fun onDraw(c: Canvas) {
        val cx = width / 2f
        val cy = height / 2f
        val h = sc.f(23f)
        c.drawLine(cx - h, cy, cx + h, cy, p)
        c.drawLine(cx, cy - h, cx, cy + h, p)
    }
}

/** The vertical three dots of the toolbar. */
class KebabView(ctx: Context, private val sc: Scale) : View(ctx) {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE }

    override fun onDraw(c: Canvas) {
        val cx = width / 2f
        val cy = height / 2f
        val gap = sc.f(19.5f)
        val r = sc.f(5.5f)
        c.drawCircle(cx, cy - gap, r, p)
        c.drawCircle(cx, cy, r, p)
        c.drawCircle(cx, cy + gap, r, p)
    }
}

/** Magnifier glyph of the search button. */
class SearchGlyphView(ctx: Context, private val sc: Scale) : View(ctx) {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        strokeWidth = sc.f(4.5f)
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
    }

    override fun onDraw(c: Canvas) {
        val cx = width / 2f
        val cy = height / 2f
        c.drawCircle(cx - sc.f(5f), cy - sc.f(5f), sc.f(17f), p)
        c.drawLine(cx + sc.f(7.5f), cy + sc.f(7.5f), cx + sc.f(21f), cy + sc.f(21f), p)
    }
}

/** Chevron ">" at the end of the Collections row. */
class ChevronView(ctx: Context, private val sc: Scale) : View(ctx) {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        strokeWidth = sc.f(4f)
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
    }

    override fun onDraw(c: Canvas) {
        val cx = width / 2f
        val cy = height / 2f
        val a = sc.f(10f)
        val b = sc.f(20f)
        c.drawLine(cx - a, cy - b, cx + a, cy, p)
        c.drawLine(cx + a, cy, cx - a, cy + b, p)
    }
}
