package com.example.memoryclone

import android.content.Context
import android.graphics.Bitmap
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions

/** Reads the Latin text in an image and turns it into a short description. */
object Analyzer {
    fun analyze(ctx: Context, bmp: Bitmap, id: Long, title: String) {
        val rec = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
        rec.process(InputImage.fromBitmap(bmp, 0))
            .addOnSuccessListener { text ->
                val lines = text.textBlocks.flatMap { b -> b.lines.map { it.text.trim() } }
                    .filter { it.length >= 4 && it.any { c -> c.isLetter() } }
                val sb = StringBuilder()
                for (l in lines) {
                    if (sb.length >= 130) break
                    if (sb.isNotEmpty()) sb.append(" · ")
                    sb.append(l)
                }
                val desc = if (sb.isEmpty()) "Image saved to Memory" else sb.toString().take(160)
                Store.finishAnalysis(ctx, id, title, desc)
                rec.close()
            }
            .addOnFailureListener {
                Store.finishAnalysis(ctx, id, title, "Image saved to Memory")
                rec.close()
            }
    }
}
