package com.example.memoryclone

import android.Manifest
import android.animation.ValueAnimator
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.Outline
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.media.MediaPlayer
import android.media.MediaRecorder
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.TextUtils
import android.util.TypedValue
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.ViewOutlineProvider
import android.view.animation.DecelerateInterpolator
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.FileProvider
import androidx.core.view.WindowCompat
import com.airbnb.lottie.LottieAnimationView
import com.airbnb.lottie.LottieDrawable
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.min
import kotlin.math.roundToInt

/**
 * Home screen of Memory, laid out in the pixel coordinates measured from the original screenshots
 * (1080 px wide reference): empty page, collapsing header, collections card, tabs, list, search button
 * and the "+" menu.
 */
class MainActivity : AppCompatActivity() {

    private companion object {
        const val HEADER_EXPANDED = 840f     // header height with the big centred title
        const val SCROLL_RANGE = 535f        // distance the header collapses over
        const val ITEM_TOP = 1540f           // first list item (expanded layout)
        const val ITEM_PITCH = 357f
        const val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT
    }

    private lateinit var sc: Scale
    private lateinit var root: FrameLayout
    private lateinit var glow: ImageView
    private lateinit var emptyBox: FrameLayout
    private lateinit var scroll: ScrollView
    private lateinit var content: FrameLayout
    private lateinit var header: FrameLayout
    private lateinit var title: TextView
    private lateinit var subtitle: TextView
    private lateinit var plus: PlusView
    private lateinit var kebab: KebabView
    private lateinit var fab: FrameLayout

    private val handler = Handler(Looper.getMainLooper())
    private var all: List<Memory> = emptyList()
    private var tabLabel = "All"
    private var query = ""
    private var lastSig = ""
    private var popup: View? = null
    private var viewer: View? = null
    private var player: MediaPlayer? = null
    private var recorder: MediaRecorder? = null
    private var recId = 0L
    private var recStart = 0L
    private var pendingCam: File? = null
    private var titleW0 = 0f

    private val tick = object : Runnable {
        override fun run() {
            refresh(false)
            handler.postDelayed(this, 1000)
        }
    }

    private val pickImage = registerForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) addImageFromUri(uri)
    }
    private val takePicture = registerForActivityResult(ActivityResultContracts.TakePicture()) { ok ->
        val f = pendingCam
        if (ok && f != null && f.exists()) {
            BitmapFactory.decodeFile(f.absolutePath)?.let { addBitmapMemory(it) }
            f.delete()
        }
    }
    private val micPermission = registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) startRecording() else Toast.makeText(this, "Microphone permission is needed", Toast.LENGTH_SHORT).show()
    }

    // ------------------------------------------------------------------ helpers

    private fun styleText(tv: TextView, size: Float, bold: Boolean, color: Int) {
        tv.setTextSize(TypedValue.COMPLEX_UNIT_PX, sc.f(size))
        tv.setTextColor(color)
        tv.includeFontPadding = false
        tv.typeface = if (bold) Typeface.DEFAULT_BOLD else Typeface.DEFAULT
    }

    /** Puts [tv] at x (1080 px reference) with its first baseline at [baseline]. */
    private fun placeText(parent: FrameLayout, tv: TextView, x: Float, baseline: Float, width: Float = -1f) {
        val lp = FrameLayout.LayoutParams(if (width < 0f) WRAP else sc.i(width), WRAP)
        lp.leftMargin = sc.i(x)
        lp.topMargin = (sc.f(baseline) + tv.paint.ascent()).roundToInt()
        parent.addView(tv, lp)
    }

    private fun linePitch(tv: TextView, pitch: Float) {
        val fm = tv.paint.fontMetrics
        tv.setLineSpacing(sc.f(pitch) - (fm.descent - fm.ascent), 1f)
    }

    private fun round(color: Int, radius: Float): GradientDrawable =
        GradientDrawable().apply { setColor(color); cornerRadius = sc.f(radius) }

    private fun appLabel(pkg: String): String {
        if (pkg == packageName || pkg.isEmpty()) return "Memory"
        return try {
            packageManager.getApplicationLabel(packageManager.getApplicationInfo(pkg, 0)).toString()
        } catch (_: Throwable) {
            pkg
        }
    }

    // ------------------------------------------------------------------ onCreate

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        sc = Scale(this)
        WindowCompat.setDecorFitsSystemWindows(window, false)
        window.statusBarColor = Color.TRANSPARENT
        window.navigationBarColor = Color.TRANSPARENT
        window.isNavigationBarContrastEnforced = false

        root = FrameLayout(this).apply { setBackgroundColor(Color.BLACK) }

        // bottom glow of the empty page (measured from the original screenshot)
        glow = ImageView(this).apply {
            scaleType = ImageView.ScaleType.FIT_XY
            try {
                assets.open("empty_glow.png").use { setImageBitmap(BitmapFactory.decodeStream(it)) }
            } catch (_: Throwable) {
            }
        }
        root.addView(glow, FrameLayout.LayoutParams(-1, 10, Gravity.BOTTOM))
        root.post {
            val lp = glow.layoutParams
            lp.height = (root.height * 1160f / 2340f).toInt()
            glow.layoutParams = lp
        }

        buildEmptyBox()
        buildList()
        buildHeader()
        buildFab()
        setContentView(root)
        applyScroll(0)
    }

    private fun buildEmptyBox() {
        emptyBox = FrameLayout(this)
        val heading = TextView(this).apply {
            text = "Save memories from anywhere"
            gravity = Gravity.CENTER_HORIZONTAL
        }
        styleText(heading, 66f, true, Color.WHITE)
        linePitch(heading, 92f)
        placeText(emptyBox, heading, 120f, 668f, 840f)

        val para = TextView(this).apply {
            text = "Swipe down with three fingers to save screens, press the Volume up and Side buttons to " +
                    "record voice notes, or use the Share menu to add content from any app."
            gravity = Gravity.CENTER_HORIZONTAL
        }
        styleText(para, 40f, false, Color.WHITE)
        linePitch(para, 52f)
        placeText(emptyBox, para, 117f, 1011f, 845f)
        root.addView(emptyBox, FrameLayout.LayoutParams(-1, -1))
    }

    private fun buildList() {
        scroll = ScrollView(this).apply {
            isVerticalScrollBarEnabled = false
            overScrollMode = View.OVER_SCROLL_NEVER
            setOnScrollChangeListener { _, _, sy, _, _ -> applyScroll(sy) }
        }
        content = FrameLayout(this)
        scroll.addView(content, FrameLayout.LayoutParams(-1, WRAP))
        root.addView(scroll, FrameLayout.LayoutParams(-1, -1))
    }

    private fun buildHeader() {
        header = FrameLayout(this).apply { setBackgroundColor(Color.BLACK) }

        title = TextView(this).apply { text = "Memory" }
        styleText(title, 56f, true, Color.WHITE)
        titleW0 = title.paint.measureText("Memory")
        header.addView(title, FrameLayout.LayoutParams(WRAP, WRAP))

        subtitle = TextView(this).apply { gravity = Gravity.CENTER_HORIZONTAL }
        styleText(subtitle, 42f, true, 0xFFC8C8C8.toInt())
        header.addView(subtitle, FrameLayout.LayoutParams(-1, WRAP))

        plus = PlusView(this, sc)
        kebab = KebabView(this, sc)
        header.addView(plus, FrameLayout.LayoutParams(sc.i(140f), sc.i(140f)).apply { leftMargin = sc.i(878.5f - 70f) })
        header.addView(kebab, FrameLayout.LayoutParams(sc.i(140f), sc.i(140f)).apply { leftMargin = sc.i(977f - 70f) })
        plus.setOnClickListener { showPlusMenu() }
        kebab.setOnClickListener { showKebabMenu() }

        root.addView(header, FrameLayout.LayoutParams(-1, sc.i(HEADER_EXPANDED)))
    }

    private fun buildFab() {
        fab = FrameLayout(this).apply { background = round(0xFF3A3A3A.toInt(), 79f) }
        fab.addView(SearchGlyphView(this, sc), FrameLayout.LayoutParams(-1, -1))
        fab.setOnClickListener { showSearchDialog() }
        root.addView(fab, FrameLayout.LayoutParams(sc.i(158f), sc.i(158f), Gravity.BOTTOM or Gravity.END).apply {
            rightMargin = sc.i(1080f - 933f - 79f)
            bottomMargin = sc.i(2340f - 2152f - 79f)
        })
    }

    // ------------------------------------------------------------------ collapsing header

    private fun applyScroll(sy: Int) {
        val range = sc.f(SCROLL_RANGE)
        val empty = all.isEmpty()
        val t = if (empty) 1f else (sy / range).coerceIn(0f, 1f)
        val hh = if (empty) sc.f(HEADER_EXPANDED - SCROLL_RANGE) else sc.f(HEADER_EXPANDED) - min(sy.toFloat(), range)
        val lp = header.layoutParams
        if (lp.height != hh.toInt()) {
            lp.height = hh.toInt()
            header.layoutParams = lp
        }
        // title: 84 px centred (baseline 401) -> 56 px left (baseline 197)
        val scale = 84f / 56f + (1f - 84f / 56f) * t
        val xe = 540f - titleW0 / sc.s * (84f / 56f) / 2f - 5f
        val x = xe + (78f - xe) * t
        val baseline = 401f + (197f - 401f) * t
        title.pivotX = 0f
        title.pivotY = -title.paint.ascent()
        title.scaleX = scale
        title.scaleY = scale
        title.translationX = sc.f(x)
        title.translationY = sc.f(baseline) + title.paint.ascent()
        // subtitle fades while collapsing
        subtitle.translationY = sc.f(484f) + subtitle.paint.ascent() - (if (empty) 0f else sy.toFloat())
        subtitle.alpha = if (empty) 0f else (1f - t * 2.5f).coerceIn(0f, 1f)
        // icons: y 727 -> 178
        val iy = 727f + (178f - 727f) * t
        plus.translationY = sc.f(iy - 70f)
        kebab.translationY = sc.f(iy - 70f)
    }

    // ------------------------------------------------------------------ lifecycle / refresh

    override fun onResume() {
        super.onResume()
        handler.post(tick)
    }

    override fun onPause() {
        super.onPause()
        handler.removeCallbacks(tick)
    }

    override fun onDestroy() {
        super.onDestroy()
        player?.release()
        try { recorder?.release() } catch (_: Throwable) {}
    }

    private fun refresh(force: Boolean) {
        all = Store.load(this)
        val sig = tabLabel + "|" + query + "|" + all.joinToString("|") { "${it.id}:${it.analyzing}:${it.title}:${it.desc}" }
        if (!force && sig == lastSig) return
        lastSig = sig
        val empty = all.isEmpty()
        emptyBox.visibility = if (empty) View.VISIBLE else View.GONE
        glow.visibility = if (empty) View.VISIBLE else View.GONE
        scroll.visibility = if (empty) View.GONE else View.VISIBLE
        fab.visibility = if (empty) View.GONE else View.VISIBLE
        subtitle.text = if (all.size == 1) "1 memory" else "${all.size} memories"
        if (!empty) buildContent()
        applyScroll(if (empty) 0 else scroll.scrollY)
    }

    // ------------------------------------------------------------------ list content

    private fun buildContent() {
        val keepY = scroll.scrollY
        val firstBuild = content.childCount == 0
        content.removeAllViews()

        // "Collections >" row
        val colTitle = TextView(this).apply { text = "Collections" }
        styleText(colTitle, 48f, true, Color.WHITE)
        placeText(content, colTitle, 73f, 925f)
        val chev = ChevronView(this, sc)
        content.addView(chev, FrameLayout.LayoutParams(sc.i(60f), sc.i(60f)).apply {
            leftMargin = sc.i(1002f - 30f)
            topMargin = sc.i(908f - 30f)
        })

        // card: Create your first collection
        val card = FrameLayout(this).apply { background = round(0xFF161616.toInt(), 50f) }
        content.addView(card, FrameLayout.LayoutParams(sc.i(968f), sc.i(343f)).apply {
            leftMargin = sc.i(56f)
            topMargin = sc.i(982f)
        })
        val cTitle = TextView(this).apply { text = "Create your first collection" }
        styleText(cTitle, 45f, true, Color.WHITE)
        placeText(card, cTitle, 28f, 1057f - 982f)
        val cDesc = TextView(this).apply { text = "Collections automatically group and organize similar memories for you." }
        styleText(cDesc, 34f, false, Color.WHITE)
        linePitch(cDesc, 46f)
        placeText(card, cDesc, 28f, 1114f - 982f, 880f)
        val create = TextView(this).apply { text = "Create" }
        styleText(create, 42f, true, Color.WHITE)
        val cw = create.paint.measureText("Create") / sc.s
        placeText(card, create, 965f - 56f - cw, 1265f - 982f)
        card.setOnClickListener { Toast.makeText(this, "Collections are coming in the next part", Toast.LENGTH_SHORT).show() }

        // tabs
        content.addView(buildTabs(), FrameLayout.LayoutParams(-1, sc.i(111f)).apply { topMargin = sc.i(1377f) })

        // list
        val shown = all.filter { m ->
            (tabLabel == "All" || appLabel(m.pkg) == tabLabel) &&
                    (query.isEmpty() || m.title.contains(query, true) || m.desc.contains(query, true))
        }
        val fmt = SimpleDateFormat("HH:mm", Locale.getDefault())
        var bottom = ITEM_TOP
        shown.forEachIndexed { i, m ->
            val top = ITEM_TOP + i * ITEM_PITCH
            addItem(m, top, fmt.format(Date(m.id)))
            bottom = top + 300f
        }
        if (shown.isEmpty()) {
            val none = TextView(this).apply { text = "No results" }
            styleText(none, 42f, false, 0xFFC8C8C8.toInt())
            placeText(content, none, 56f, ITEM_TOP + 60f)
        }

        // collapsible only when the expanded layout does not fit
        val contentBottom = sc.f(bottom + 330f)
        scroll.post {
            val vh = scroll.height
            val total = if (contentBottom > vh) maxOf(contentBottom, vh + sc.f(SCROLL_RANGE)) else contentBottom
            content.minimumHeight = total.roundToInt()
            val lp = content.layoutParams
            lp.height = total.roundToInt()
            content.layoutParams = lp
            scroll.post {
                if (firstBuild && contentBottom > vh) scroll.scrollTo(0, sc.f(SCROLL_RANGE).roundToInt())
                else scroll.scrollTo(0, keepY)
                applyScroll(scroll.scrollY)
            }
        }
    }

    private fun buildTabs(): View {
        val hs = HorizontalScrollView(this).apply { isHorizontalScrollBarEnabled = false }
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val labels = mutableListOf("All")
        all.forEach { val l = appLabel(it.pkg); if (!labels.contains(l)) labels.add(l) }
        if (query.isNotEmpty()) {
            val chip = tabView("\"$query\"  \u2715", true)
            chip.setOnClickListener { query = ""; refresh(true) }
            row.addView(chip)
        } else {
            for (l in labels) {
                val tab = tabView(l, l == tabLabel)
                tab.setOnClickListener { tabLabel = l; refresh(true) }
                row.addView(tab)
            }
        }
        hs.addView(row)
        val wrap = FrameLayout(this)
        wrap.addView(hs, FrameLayout.LayoutParams(-1, -1).apply { leftMargin = sc.i(56f) })
        return wrap
    }

    private fun tabView(label: String, selected: Boolean): TextView = TextView(this).apply {
        text = label
        gravity = Gravity.CENTER
        styleText(this, 39f, selected, if (selected) Color.WHITE else 0xFFC8C8C8.toInt())
        setPadding(sc.i(34f), 0, sc.i(34f), 0)
        minWidth = sc.i(111f)
        layoutParams = LinearLayout.LayoutParams(WRAP, sc.i(111f))
        if (selected) background = round(0xFF343434.toInt(), 56f)
    }

    private fun addItem(m: Memory, top: Float, time: String) {
        // thumbnail 225 x 300 with a thin border
        val thumb = ImageView(this).apply {
            scaleType = ImageView.ScaleType.CENTER_CROP
            setBackgroundColor(0xFF1C1C1E.toInt())
            clipToOutline = true
            outlineProvider = object : ViewOutlineProvider() {
                override fun getOutline(view: View, outline: Outline) {
                    outline.setRoundRect(0, 0, view.width, view.height, sc.f(30f))
                }
            }
            foreground = GradientDrawable().apply {
                setColor(Color.TRANSPARENT)
                setStroke(sc.i(1.5f).coerceAtLeast(1), 0xFF404040.toInt())
                cornerRadius = sc.f(30f)
            }
            val f = Store.thumbFile(this@MainActivity, m.id)
            if (f.exists()) {
                setImageBitmap(BitmapFactory.decodeFile(f.absolutePath))
            } else if (m.type == "text" || m.type == "voice") {
                scaleType = ImageView.ScaleType.CENTER
                setImageResource(if (m.type == "text") R.drawable.ic_pop_text else R.drawable.ic_pop_mic)
                setPadding(sc.i(60f), sc.i(100f), sc.i(60f), sc.i(100f))
                scaleType = ImageView.ScaleType.FIT_CENTER
            }
        }
        content.addView(thumb, FrameLayout.LayoutParams(sc.i(225f), sc.i(300f)).apply {
            leftMargin = sc.i(56f)
            topMargin = sc.i(top)
        })

        val textX = if (m.analyzing) 403f else 324f
        if (m.analyzing) {
            val star = LottieAnimationView(this).apply {
                setAnimation("intelligence_progress_color.json")
                repeatCount = LottieDrawable.INFINITE
                playAnimation()
            }
            content.addView(star, FrameLayout.LayoutParams(sc.i(54f), sc.i(54f)).apply {
                leftMargin = sc.i(329f)
                topMargin = sc.i(top + 60f)
            })
            val t = TextView(this).apply { text = "Analyzing..." }
            styleText(t, 42f, true, Color.WHITE)
            placeText(content, t, textX, top + 72f)
        } else {
            val t = TextView(this).apply {
                text = m.title
                maxLines = 1
                ellipsize = TextUtils.TruncateAt.END
            }
            styleText(t, 42f, true, Color.WHITE)
            placeText(content, t, textX, top + 72f, 1080f - textX - 56f)
            val d = TextView(this).apply {
                text = m.desc
                maxLines = 2
                ellipsize = TextUtils.TruncateAt.END
            }
            styleText(d, 34f, false, 0xFFB5B5B5.toInt())
            linePitch(d, 47f)
            placeText(content, d, textX, top + 141f, 1080f - textX - 56f)
        }

        // source app icon + time
        val ic = ImageView(this).apply {
            scaleType = ImageView.ScaleType.FIT_CENTER
            try {
                setImageDrawable(packageManager.getApplicationIcon(if (m.pkg.isEmpty()) packageName else m.pkg))
            } catch (_: Throwable) {
                setImageDrawable(packageManager.getApplicationIcon(packageName))
            }
        }
        content.addView(ic, FrameLayout.LayoutParams(sc.i(42f), sc.i(42f)).apply {
            leftMargin = sc.i(324f)
            topMargin = sc.i(top + 235f)
        })
        val tm = TextView(this).apply { text = time }
        styleText(tm, 28f, false, 0xFFBDBDBD.toInt())
        placeText(content, tm, 381f, top + 268f)

        // tap area over the whole row
        val hit = View(this)
        content.addView(hit, FrameLayout.LayoutParams(-1, sc.i(300f)).apply { topMargin = sc.i(top) })
        hit.setOnClickListener { openMemory(m) }
        hit.setOnLongClickListener { confirmDelete(m); true }
    }

    // ------------------------------------------------------------------ popups

    private fun dismissPopup() {
        popup?.let { root.removeView(it) }
        popup = null
    }

    private fun showMenu(items: List<Pair<Int, String>>, actions: List<() -> Unit>, anchorCenterY: Float) {
        dismissPopup()
        val overlay = FrameLayout(this).apply { setOnClickListener { dismissPopup() } }
        val rows = items.size
        val cardH = rows * 133f + 33f
        val card = FrameLayout(this).apply {
            background = round(0xFF282828.toInt(), 56f)
            elevation = sc.f(24f)
        }
        items.forEachIndexed { i, it ->
            val cy = 18f + 66.5f + i * 133f
            val icon = ImageView(this).apply { setImageResource(it.first) }
            card.addView(icon, FrameLayout.LayoutParams(sc.i(48f), sc.i(48f)).apply {
                leftMargin = sc.i(62f)
                topMargin = sc.i(cy - 24f)
            })
            val label = TextView(this).apply { text = it.second }
            styleText(label, 46f, false, Color.WHITE)
            card.addView(label, FrameLayout.LayoutParams(WRAP, WRAP).apply {
                leftMargin = sc.i(144f)
                topMargin = (sc.f(cy) - (label.paint.descent() - label.paint.ascent()) / 2f).roundToInt()
            })
            val hit = View(this)
            card.addView(hit, FrameLayout.LayoutParams(-1, sc.i(133f)).apply { topMargin = sc.i(cy - 66.5f) })
            hit.setOnClickListener {
                dismissPopup()
                actions[i]()
            }
        }
        val top = (anchorCenterY - 85f).coerceAtLeast(30f)
        overlay.addView(card, FrameLayout.LayoutParams(sc.i(481f), sc.i(cardH)).apply {
            leftMargin = sc.i(574f)
            topMargin = sc.i(top)
        })
        root.addView(overlay, FrameLayout.LayoutParams(-1, -1))
        popup = overlay
        card.post {
            card.pivotX = card.width.toFloat()
            card.pivotY = 0f
            card.scaleX = 0.6f
            card.scaleY = 0.6f
            card.alpha = 0f
            card.animate().scaleX(1f).scaleY(1f).alpha(1f).setDuration(170).setInterpolator(DecelerateInterpolator()).start()
        }
    }

    private fun showPlusMenu() {
        val cy = (plus.translationY + plus.height / 2f) / sc.s
        showMenu(
            listOf(
                R.drawable.ic_pop_mic to "Voice note",
                R.drawable.ic_pop_text to "Text",
                R.drawable.ic_pop_image to "Image",
                R.drawable.ic_pop_camera to "Camera"
            ),
            listOf({ startRecording() }, { addTextDialog() }, { pickImage.launch("image/*") }, { openCamera() }),
            cy
        )
    }

    private fun showKebabMenu() {
        val cy = (kebab.translationY + kebab.height / 2f) / sc.s
        showMenu(
            listOf(R.drawable.ic_pop_settings to "Settings"),
            listOf({ startActivity(Intent(this, SettingsActivity::class.java)) }),
            cy
        )
    }

    override fun onBackPressed() {
        when {
            viewer != null -> closeViewer()
            popup != null -> dismissPopup()
            else -> super.onBackPressed()
        }
    }

    // ------------------------------------------------------------------ adding memories

    private fun addBitmapMemory(bmp: Bitmap) {
        val id = System.currentTimeMillis()
        Store.saveShot(this, id, bmp)
        Store.add(this, Memory(id, "Analyzing...", "", packageName, true, "image"))
        refresh(true)
        Analyzer.analyze(applicationContext, bmp, id, "Memory")
    }

    private fun addImageFromUri(uri: Uri) {
        try {
            val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
            var sample = 1
            while (bounds.outWidth / sample > 2400 || bounds.outHeight / sample > 2400) sample *= 2
            val opts = BitmapFactory.Options().apply { inSampleSize = sample }
            val bmp = contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, opts) }
            if (bmp != null) addBitmapMemory(bmp)
        } catch (_: Throwable) {
            Toast.makeText(this, "Couldn't open that image", Toast.LENGTH_SHORT).show()
        }
    }

    private fun openCamera() {
        val f = File(cacheDir, "cam_${System.currentTimeMillis()}.jpg")
        pendingCam = f
        val uri = FileProvider.getUriForFile(this, "com.example.memoryclone.files", f)
        takePicture.launch(uri)
    }

    private fun addTextDialog() {
        val input = EditText(this).apply {
            hint = "Write something to remember"
            minLines = 4
            gravity = Gravity.TOP or Gravity.START
            setPadding(sc.i(48f), sc.i(32f), sc.i(48f), sc.i(32f))
        }
        AlertDialog.Builder(this)
            .setTitle("Text")
            .setView(input)
            .setPositiveButton("Save") { _, _ ->
                val txt = input.text.toString().trim()
                if (txt.isNotEmpty()) {
                    val id = System.currentTimeMillis()
                    val first = txt.lines().first().take(40)
                    Store.add(this, Memory(id, first, txt, packageName, false, "text"))
                    refresh(true)
                }
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    // ------------------------------------------------------------------ voice note

    private fun startRecording() {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            micPermission.launch(Manifest.permission.RECORD_AUDIO)
            return
        }
        try {
            recId = System.currentTimeMillis()
            val r = MediaRecorder(this)
            r.setAudioSource(MediaRecorder.AudioSource.MIC)
            r.setOutputFormat(MediaRecorder.OutputFormat.MPEG_4)
            r.setAudioEncoder(MediaRecorder.AudioEncoder.AAC)
            r.setOutputFile(Store.audioFile(this, recId).absolutePath)
            r.prepare()
            r.start()
            recorder = r
            recStart = System.currentTimeMillis()
        } catch (_: Throwable) {
            Toast.makeText(this, "Couldn't start recording", Toast.LENGTH_SHORT).show()
            return
        }
        val timer = TextView(this).apply {
            text = "0:00"
            gravity = Gravity.CENTER
            setPadding(0, sc.i(40f), 0, sc.i(20f))
        }
        styleText(timer, 72f, true, Color.WHITE)
        val tickRec = object : Runnable {
            override fun run() {
                val s = ((System.currentTimeMillis() - recStart) / 1000).toInt()
                timer.text = "%d:%02d".format(s / 60, s % 60)
                handler.postDelayed(this, 500)
            }
        }
        handler.post(tickRec)
        val dlg = AlertDialog.Builder(this)
            .setTitle("Voice note")
            .setView(timer)
            .setCancelable(false)
            .setPositiveButton("Stop") { _, _ -> }
            .setNegativeButton("Cancel") { _, _ -> }
            .create()
        dlg.setOnDismissListener { handler.removeCallbacks(tickRec) }
        dlg.show()
        dlg.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
            val secs = ((System.currentTimeMillis() - recStart) / 1000).toInt()
            finishRecording(true, secs)
            dlg.dismiss()
        }
        dlg.getButton(AlertDialog.BUTTON_NEGATIVE).setOnClickListener {
            finishRecording(false, 0)
            dlg.dismiss()
        }
    }

    private fun finishRecording(save: Boolean, secs: Int) {
        try { recorder?.stop() } catch (_: Throwable) {}
        try { recorder?.release() } catch (_: Throwable) {}
        recorder = null
        if (save) {
            Store.add(this, Memory(recId, "Voice note", "%d:%02d".format(secs / 60, secs % 60), packageName, false, "voice"))
            refresh(true)
        } else {
            Store.audioFile(this, recId).delete()
        }
    }

    // ------------------------------------------------------------------ open / delete / search

    private fun openMemory(m: Memory) {
        when (m.type) {
            "text" -> AlertDialog.Builder(this).setTitle(m.title).setMessage(m.desc).setPositiveButton("Close", null).show()
            "voice" -> {
                val f = Store.audioFile(this, m.id)
                try {
                    player?.release()
                    player = MediaPlayer().apply { setDataSource(f.absolutePath); prepare(); start() }
                    Toast.makeText(this, "Playing voice note", Toast.LENGTH_SHORT).show()
                } catch (_: Throwable) {
                    Toast.makeText(this, "Couldn't play this voice note", Toast.LENGTH_SHORT).show()
                }
            }
            else -> {
                val f = Store.fullFile(this, m.id)
                if (!f.exists()) return
                val iv = ImageView(this).apply {
                    scaleType = ImageView.ScaleType.FIT_CENTER
                    setBackgroundColor(Color.BLACK)
                    setImageBitmap(BitmapFactory.decodeFile(f.absolutePath))
                    setOnClickListener { closeViewer() }
                }
                root.addView(iv, FrameLayout.LayoutParams(-1, -1))
                viewer = iv
            }
        }
    }

    private fun closeViewer() {
        viewer?.let { root.removeView(it) }
        viewer = null
    }

    private fun confirmDelete(m: Memory) {
        AlertDialog.Builder(this)
            .setTitle("Delete this memory?")
            .setPositiveButton("Delete") { _, _ ->
                Store.delete(this, m.id)
                refresh(true)
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun showSearchDialog() {
        val input = EditText(this).apply {
            hint = "Search memories"
            setText(query)
            setPadding(sc.i(48f), sc.i(32f), sc.i(48f), sc.i(32f))
        }
        AlertDialog.Builder(this)
            .setTitle("Search")
            .setView(input)
            .setPositiveButton("Search") { _, _ ->
                query = input.text.toString().trim()
                refresh(true)
            }
            .setNegativeButton("Cancel", null)
            .show()
    }
}
