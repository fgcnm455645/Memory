package com.example.memoryclone

import android.content.Context
import android.graphics.Bitmap
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.FileOutputStream

/** One saved memory. type: "screen", "image", "text" or "voice". */
data class Memory(
    val id: Long,
    var title: String,
    var desc: String,
    val pkg: String,
    var analyzing: Boolean,
    val type: String = "screen"
)

object Store {
    private fun dataFile(ctx: Context) = File(ctx.filesDir, "memories.json")
    private fun shotsDir(ctx: Context) = File(ctx.filesDir, "shots").also { it.mkdirs() }

    fun fullFile(ctx: Context, id: Long) = File(shotsDir(ctx), "$id.jpg")
    fun thumbFile(ctx: Context, id: Long) = File(shotsDir(ctx), "${id}_t.jpg")
    fun audioFile(ctx: Context, id: Long) = File(shotsDir(ctx), "$id.m4a")

    /** Saves the full image and a 360 px wide thumbnail. */
    fun saveShot(ctx: Context, id: Long, bmp: Bitmap) {
        try {
            FileOutputStream(fullFile(ctx, id)).use { bmp.compress(Bitmap.CompressFormat.JPEG, 90, it) }
            val tw = 360
            val th = (tw.toFloat() * bmp.height / bmp.width).toInt().coerceAtLeast(1)
            val thumb = Bitmap.createScaledBitmap(bmp, tw, th, true)
            FileOutputStream(thumbFile(ctx, id)).use { thumb.compress(Bitmap.CompressFormat.JPEG, 85, it) }
        } catch (_: Throwable) {
        }
    }

    @Synchronized
    fun load(ctx: Context): MutableList<Memory> {
        val out = mutableListOf<Memory>()
        try {
            val f = dataFile(ctx)
            if (!f.exists()) return out
            val arr = JSONArray(f.readText())
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                out.add(
                    Memory(
                        o.getLong("id"), o.getString("title"), o.getString("desc"),
                        o.getString("pkg"), o.getBoolean("analyzing"), o.optString("type", "screen")
                    )
                )
            }
        } catch (_: Throwable) {
        }
        return out
    }

    @Synchronized
    private fun save(ctx: Context, list: List<Memory>) {
        val arr = JSONArray()
        for (m in list) {
            arr.put(
                JSONObject()
                    .put("id", m.id).put("title", m.title).put("desc", m.desc)
                    .put("pkg", m.pkg).put("analyzing", m.analyzing).put("type", m.type)
            )
        }
        dataFile(ctx).writeText(arr.toString())
    }

    @Synchronized
    fun add(ctx: Context, m: Memory) {
        val list = load(ctx)
        list.add(0, m)
        save(ctx, list)
    }

    @Synchronized
    fun finishAnalysis(ctx: Context, id: Long, title: String, desc: String) {
        val list = load(ctx)
        list.firstOrNull { it.id == id }?.let {
            it.title = title
            it.desc = desc
            it.analyzing = false
        }
        save(ctx, list)
    }

    @Synchronized
    fun delete(ctx: Context, id: Long) {
        val list = load(ctx)
        list.removeAll { it.id == id }
        save(ctx, list)
        try { fullFile(ctx, id).delete() } catch (_: Throwable) {}
        try { thumbFile(ctx, id).delete() } catch (_: Throwable) {}
        try { audioFile(ctx, id).delete() } catch (_: Throwable) {}
    }
}
