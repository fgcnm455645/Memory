package com.example.memorywave

import android.animation.Animator
import android.animation.AnimatorListenerAdapter
import android.animation.ValueAnimator
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.graphics.Color
import android.graphics.RenderEffect
import android.graphics.RuntimeShader
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.animation.LinearInterpolator
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Toast
import android.widget.TextView
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import com.airbnb.lottie.LottieAnimationView
import java.io.File

/**
 * Part 0b - "Save to Memory" wave test.
 *
 * - The wave (screen squeeze + ripple that pulls the screen down into the bottom icon)
 *   uses the ORIGINAL AGSL shader found in Samsung Memory's classes.dex, unchanged.
 * - The bottom icon uses the ORIGINAL "app icon 2" Lottie + its 3 PNG layers.
 * - Timing of the wave (about 650 ms) and the blue glow / caption are matched by eye
 *   from the screen recording, so they are approximate. Use Speed to compare.
 */
class MainActivity : AppCompatActivity() {

    companion object {
        const val SHADER = """
            uniform shader content;
            uniform float2 uRes;
            uniform float uProgress;

            float2 distortUV(float2 uv, float p, float aspect) {
                float sq = smoothstep(0.02, 0.29, p) *
                    (1.0 - smoothstep(0.333, 0.947, p));
                float2 sc = float2(1.0 + 0.015 * sq, 1.0 - 0.02 * sq);
                float2 anchor = float2(0.5, 1.0);
                float2 q = float2(uv.x, uv.y - 4.29 / 3200.0 * sq);
                float2 lp = anchor + (q - anchor) / max(sc, float2(0.0001));
                float over = max(p - 0.39, 0.0);
                float amp = smoothstep(0.0, 0.33, p) *
                    exp(-pow(over / 0.098, 1.4));
                float front = 1.5 * p + 11.25 * over * over;
                float2 center = float2(0.5, -0.035);
                float d = length(float2((lp.x - center.x) * aspect, lp.y - center.y));
                float inside = 1.0 - smoothstep(front - 0.15, front + 0.15, d);
                lp -= float2(-0.002, 0.03) * amp * inside;
                float bx = 2.0 * (uv.x - center.x);
                float depth = max(0.3 * (1.0 + 0.4 * bx * bx), 0.001);
                float t = clamp(uv.y / depth, 0.0, 1.0);
                float t2 = t * t;
                float dy = (uv.y - lp.y) * t * (1.25 - 0.25 * t2 * t2);
                lp.y = uv.y - min(dy, 0.9 * uv.y);
                return lp;
            }

            half4 main(float2 p) {
                float2 resolution = max(uRes, float2(1.0));
                float2 uv = p / resolution;
                float progress = clamp(uProgress, 0.0, 1.0);
                float2 source = uv;
                if (progress > 0.0 && progress < 1.0) {
                    source = distortUV(uv, progress, resolution.x / resolution.y);
                }
                return content.eval(clamp(
                    source * resolution, float2(0.5), resolution - float2(0.5)
                ));
            }
        """

        const val WAVE_MS = 650f        // length of the shader progress 0..1 (estimated from video)
        const val ICON_START = 1250f    // icon Lottie start (estimated from video)
        const val ICON_MS = 2000f       // icon Lottie is 120 frames at 60 fps
        const val TOTAL_MS = 3400f
    }

    private lateinit var root: FrameLayout
    private lateinit var stage: FrameLayout
    private lateinit var image: ImageView
    private lateinit var tint: View
    private lateinit var glow: View
    private lateinit var icon: LottieAnimationView
    private lateinit var caption: TextView
    private lateinit var speedBtn: TextView
    private lateinit var waveBtn: TextView
    private var waveOn = true
    private var flagSet = false
    private val crashFile by lazy { File(filesDir, "crash.txt") }
    private val prefs by lazy { getSharedPreferences("wave", MODE_PRIVATE) }

    private val shader by lazy { RuntimeShader(SHADER) }
    private var anim: ValueAnimator? = null
    private var speedIdx = 0
    private val speeds = floatArrayOf(1f, 0.5f, 0.25f)

    private val pickImage = registerForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) image.setImageURI(uri)
    }

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        installCrashHandler()
        // If the wave crashed the app natively last time, start with the wave disabled.
        val crashedLastTime = prefs.getBoolean("wave_pending", false)
        if (crashedLastTime) {
            waveOn = false
            prefs.edit().putBoolean("wave_pending", false).commit()
        }
        WindowCompat.setDecorFitsSystemWindows(window, false)
        WindowInsetsControllerCompat(window, window.decorView).apply {
            hide(WindowInsetsCompat.Type.systemBars())
            systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        }

        root = FrameLayout(this).apply { setBackgroundColor(Color.BLACK) }
        stage = FrameLayout(this)
        stage.setOnClickListener { play() }

        image = ImageView(this).apply {
            scaleType = ImageView.ScaleType.CENTER_CROP
            setImageResource(R.drawable.sample_home)
        }
        stage.addView(image, FrameLayout.LayoutParams(-1, -1))

        tint = View(this).apply {
            background = GradientDrawable(
                GradientDrawable.Orientation.TOP_BOTTOM,
                intArrayOf(0xFF8A7BFF.toInt(), 0xFF3F6BE0.toInt(), 0x00000000)
            )
            alpha = 0f
        }
        stage.addView(tint, FrameLayout.LayoutParams(-1, -1))

        glow = View(this).apply { alpha = 0f }
        stage.addView(glow, FrameLayout.LayoutParams(1, 1))

        icon = LottieAnimationView(this).apply {
            setImageAssetsFolder("images/")
            setAnimation("memory_app_icon.json")
            progress = 0f
            visibility = View.INVISIBLE
        }
        stage.addView(icon, FrameLayout.LayoutParams(1, 1))

        caption = TextView(this).apply {
            text = "Saved to Memory"
            textSize = 12f
            setTextColor(Color.WHITE)
            typeface = Typeface.DEFAULT_BOLD
            alpha = 0f
        }
        stage.addView(caption, FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.WRAP_CONTENT, FrameLayout.LayoutParams.WRAP_CONTENT))

        root.addView(stage, FrameLayout.LayoutParams(-1, -1))

        // Controls (outside the stage so the wave does not distort them)
        speedBtn = pill("Speed: 1x") {
            speedIdx = (speedIdx + 1) % speeds.size
            speedBtn.text = "Speed: " + (if (speedIdx == 0) "1x" else if (speedIdx == 1) "0.5x" else "0.25x")
            play()
        }
        waveBtn = pill(if (waveOn) "Wave: ON" else "Wave: OFF") {
            waveOn = !waveOn
            waveBtn.text = if (waveOn) "Wave: ON" else "Wave: OFF"
            if (!waveOn) image.setRenderEffect(null)
            play()
        }
        val controls = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_HORIZONTAL }
        val row1 = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER }
        val row2 = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER }
        val lp = { LinearLayout.LayoutParams(-2, -2).apply { marginStart = dp(5); marginEnd = dp(5); topMargin = dp(5) } }
        row1.addView(pill("Play") { play() }, lp())
        row1.addView(pill("Pick image") { pickImage.launch("image/*") }, lp())
        row2.addView(speedBtn, lp())
        row2.addView(waveBtn, lp())
        controls.addView(row1)
        controls.addView(row2)
        root.addView(controls, FrameLayout.LayoutParams(-2, -2, Gravity.TOP or Gravity.CENTER_HORIZONTAL).apply {
            topMargin = dp(40)
        })

        setContentView(root)
        root.post { layoutOverlays(); update(0f) }

        if (crashedLastTime) {
            Toast.makeText(this, "The wave shader crashed the app last time, so Wave is now OFF.", Toast.LENGTH_LONG).show()
        }
        if (crashFile.exists()) {
            val report = try { crashFile.readText() } catch (_: Throwable) { "" }
            crashFile.delete()
            if (report.isNotBlank()) showCrashReport(report)
        }
    }

    private fun layoutOverlays() {
        val w = stage.width
        val h = stage.height
        val cy = h * 0.895f
        val iconSize = (w * 0.30f).toInt()
        icon.layoutParams = FrameLayout.LayoutParams(iconSize, iconSize, Gravity.TOP or Gravity.CENTER_HORIZONTAL).apply {
            topMargin = (cy - iconSize / 2f).toInt()
        }
        val glowSize = (w * 0.95f).toInt()
        glow.background = GradientDrawable().apply {
            gradientType = GradientDrawable.RADIAL_GRADIENT
            gradientRadius = glowSize / 2f
            colors = intArrayOf(0xCCB58CFF.toInt(), 0x00B58CFF)
        }
        glow.layoutParams = FrameLayout.LayoutParams(glowSize, glowSize, Gravity.TOP or Gravity.CENTER_HORIZONTAL).apply {
            topMargin = (cy - glowSize / 2f).toInt()
        }
        caption.layoutParams = FrameLayout.LayoutParams(-2, -2, Gravity.TOP or Gravity.CENTER_HORIZONTAL).apply {
            topMargin = (cy + iconSize * 0.30f).toInt()
        }
    }

    private fun seg(ms: Float, a: Float, b: Float): Float = ((ms - a) / (b - a)).coerceIn(0f, 1f)

    private fun update(ms: Float) {
        // 1) the wave: original shader, progress 0..1
        val p = (ms / WAVE_MS).coerceIn(0f, 1f)
        if (!waveOn || p <= 0f || p >= 1f || image.width == 0) {
            image.setRenderEffect(null)
        } else {
            try {
                if (!flagSet) {
                    prefs.edit().putBoolean("wave_pending", true).commit()
                    flagSet = true
                }
                shader.setFloatUniform("uRes", image.width.toFloat(), image.height.toFloat())
                shader.setFloatUniform("uProgress", p)
                image.setRenderEffect(RenderEffect.createRuntimeShaderEffect(shader, "content"))
            } catch (e: Throwable) {
                waveOn = false
                image.setRenderEffect(null)
                waveBtn.text = "Wave: OFF"
                showCrashReport("Wave shader error (caught):\n" + android.util.Log.getStackTraceString(e))
            }
        }
        // 2) blue-violet tint over the screen (approximate)
        tint.alpha = 0.55f * seg(ms, 450f, 1100f) * (1f - seg(ms, 1500f, 2800f))
        // 3) icon + glow + caption (icon = original Lottie, driven by the same timeline)
        val inIcon = ms >= ICON_START && ms < ICON_START + ICON_MS
        icon.visibility = if (inIcon) View.VISIBLE else View.INVISIBLE
        icon.progress = seg(ms, ICON_START, ICON_START + ICON_MS)
        glow.alpha = seg(ms, ICON_START, ICON_START + 250f) * (1f - seg(ms, 2600f, 3300f))
        caption.alpha = seg(ms, ICON_START + 100f, ICON_START + 400f) * (1f - seg(ms, 2700f, 3200f))
    }

    private fun play() {
        anim?.cancel()
        update(0f)
        val total = TOTAL_MS / speeds[speedIdx]
        anim = ValueAnimator.ofFloat(0f, TOTAL_MS).apply {
            duration = total.toLong()
            interpolator = LinearInterpolator()
            addUpdateListener { update(it.animatedValue as Float) }
            addListener(object : AnimatorListenerAdapter() {
                override fun onAnimationEnd(animation: Animator) {
                    if (flagSet) {
                        prefs.edit().putBoolean("wave_pending", false).commit()
                        flagSet = false
                    }
                }
            })
            start()
        }
    }

    private fun installCrashHandler() {
        val f = crashFile
        val old = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { t, e ->
            try { f.writeText(android.util.Log.getStackTraceString(e)) } catch (_: Throwable) {}
            old?.uncaughtException(t, e)
        }
    }

    private fun showCrashReport(text: String) {
        val tv = TextView(this).apply {
            this.text = text
            textSize = 10f
            setTextColor(Color.WHITE)
            setTextIsSelectable(true)
            setPadding(dp(12), dp(70), dp(12), dp(90))
        }
        try {
            val cm0 = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            cm0.setPrimaryClip(ClipData.newPlainText("error", text))
        } catch (_: Throwable) {}
        val overlay = FrameLayout(this).apply { setBackgroundColor(0xF2000000.toInt()) }
        overlay.addView(ScrollView(this).apply { addView(tv) }, FrameLayout.LayoutParams(-1, -1))
        val bar = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER }
        bar.addView(pill("Copy error") {
            val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            cm.setPrimaryClip(ClipData.newPlainText("error", text))
            Toast.makeText(this, "Copied", Toast.LENGTH_SHORT).show()
        }, LinearLayout.LayoutParams(-2, -2).apply { marginEnd = dp(8) })
        bar.addView(pill("Close") { root.removeView(overlay) })
        overlay.addView(bar, FrameLayout.LayoutParams(-2, -2, Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL).apply { bottomMargin = dp(36) })
        root.addView(overlay, FrameLayout.LayoutParams(-1, -1))
    }

    private fun pill(text: String, onClick: (View) -> Unit): TextView {
        return TextView(this).apply {
            this.text = text
            textSize = 13f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            setPadding(dp(14), dp(9), dp(14), dp(9))
            background = GradientDrawable().apply {
                cornerRadius = dp(24).toFloat()
                setColor(0xCC2B2B2D.toInt())
            }
            setOnClickListener(onClick)
        }
    }
}
