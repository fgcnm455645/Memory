package com.example.memoryclone

/** Original AGSL shader from Samsung Memory (classes.dex), unchanged. */
object WaveShader {
    const val SRC = """
            uniform shader content;
            uniform float2 uRes;
            uniform float uProgress;

            float2 distortUV(float2 uv, float p, float aspect) {
                float sq = smoothstep(0.02, 0.29, p) *
                    (1.0 - smoothstep(0.333, 0.947, p));
                float2 sc = float2(1.0 + 0.015 * sq, 1.0 - 0.02 * sq);
                float2 anchor = float2(0.5, 1.0);
                float2 q = float2(uv.x, uv.y - 4.29 / 3200.0 * sq);
                float2 lp = anchor + (q - anchor) / max(sc, float2(0.0001));
                float over = max(p - 0.39, 0.0);
                float amp = smoothstep(0.0, 0.33, p) *
                    exp(-pow(over / 0.098, 1.4));
                float front = 1.5 * p + 11.25 * over * over;
                float2 center = float2(0.5, -0.035);
                float d = length(float2((lp.x - center.x) * aspect, lp.y - center.y));
                float inside = 1.0 - smoothstep(front - 0.15, front + 0.15, d);
                lp -= float2(-0.002, 0.03) * amp * inside;
                float bx = 2.0 * (uv.x - center.x);
                float depth = max(0.3 * (1.0 + 0.4 * bx * bx), 0.001);
                float t = clamp(uv.y / depth, 0.0, 1.0);
                float t2 = t * t;
                float dy = (uv.y - lp.y) * t * (1.25 - 0.25 * t2 * t2);
                lp.y = uv.y - min(dy, 0.9 * uv.y);
                return lp;
            }

            half4 main(float2 p) {
                float2 resolution = max(uRes, float2(1.0));
                float2 uv = p / resolution;
                float progress = clamp(uProgress, 0.0, 1.0);
                float2 source = uv;
                if (progress > 0.0 && progress < 1.0) {
                    source = distortUV(uv, progress, resolution.x / resolution.y);
                }
                return content.eval(clamp(
                    source * resolution, float2(0.5), resolution - float2(0.5)
                ));
            }
        """
}
