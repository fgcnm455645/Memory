package com.example.memoryclone

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.widget.Toast

/**
 * Invisible "Save to Memory" action. Assign it to Side key > Double press > Open app.
 * It finishes immediately so the screen underneath is what gets captured.
 */
class TriggerActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val s = CaptureService.instance
        if (s != null) {
            s.capture()
        } else {
            Toast.makeText(this, "Turn on Memory in Accessibility settings first", Toast.LENGTH_LONG).show()
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        }
        finish()
        overridePendingTransition(0, 0)
    }
}
