package com.example.memoryclone

import android.content.Intent
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.Outline
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.view.ViewOutlineProvider
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.airbnb.lottie.LottieAnimationView
import com.airbnb.lottie.LottieDrawable
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Part 1 screen: setup + a plain list to verify that memories are saved.
 * (The exact copy of the original Memory home screen comes in Part 2.)
 */
class MainActivity : AppCompatActivity() {

    private lateinit var statusTv: TextView
    private lateinit var list: LinearLayout
    private val h = Handler(Looper.getMainLooper())
    private var lastSig = ""

    private val tick = object : Runnable {
        override fun run() {
            refresh()
            h.postDelayed(this, 1000)
        }
    }

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(56), dp(20), dp(24))
        }
        col.addView(text("Memory", 28f, Color.WHITE, true))

        statusTv = text("", 14f, 0xFFCCCCCC.toInt(), false).apply { setPadding(0, dp(14), 0, dp(8)) }
        col.addView(statusTv)

        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        row.addView(pill("Turn on in Accessibility") {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        })
        row.addView(pill("Test save (3 s)") {
            val s = CaptureService.instance
            if (s == null) {
                Toast.makeText(this, "Turn on the accessibility service first", Toast.LENGTH_LONG).show()
            } else {
                Toast.makeText(this, "Saving the home screen in 3 seconds...", Toast.LENGTH_SHORT).show()
                moveTaskToBack(true)
                s.capture(3000)
            }
        }, LinearLayout.LayoutParams(-2, -2).apply { marginStart = dp(8) })
        col.addView(row)

        col.addView(text(
            "To use the power button:\nSettings > Advanced features > Side key > Double press > Open app > \"Save to Memory\".",
            12f, 0xFF999999.toInt(), false
        ).apply { setPadding(0, dp(14), 0, dp(14)) })

        list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        col.addView(list)

        setContentView(ScrollView(this).apply {
            setBackgroundColor(Color.BLACK)
            addView(col)
        })
    }

    override fun onResume() {
        super.onResume()
        h.post(tick)
    }

    override fun onPause() {
        super.onPause()
        h.removeCallbacks(tick)
    }

    private fun refresh() {
        val on = CaptureService.instance != null
        statusTv.text = if (on) "Accessibility service: ON" else "Accessibility service: OFF (turn it on to save screens)"
        val items = Store.load(this)
        val sig = on.toString() + items.joinToString("|") { "${it.id}:${it.analyzing}:${it.title}" }
        if (sig == lastSig) return
        lastSig = sig
        list.removeAllViews()
        val fmt = SimpleDateFormat("HH:mm", Locale.getDefault())
        for (m in items) list.addView(rowFor(m, fmt.format(Date(m.id))))
    }

    private fun rowFor(m: Memory, time: String): View {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(0, dp(10), 0, dp(10))
        }
        val thumb = ImageView(this).apply {
            scaleType = ImageView.ScaleType.CENTER_CROP
            setBackgroundColor(0xFF1C1C1E.toInt())
            clipToOutline = true
            outlineProvider = object : ViewOutlineProvider() {
                override fun getOutline(view: View, outline: Outline) {
                    outline.setRoundRect(0, 0, view.width, view.height, dp(12).toFloat())
                }
            }
            val f = Store.thumbFile(this@MainActivity, m.id)
            if (f.exists()) setImageBitmap(BitmapFactory.decodeFile(f.absolutePath))
        }
        row.addView(thumb, LinearLayout.LayoutParams(dp(84), dp(112)))

        val c = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        if (m.analyzing) {
            val t = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
            val star = LottieAnimationView(this).apply {
                setAnimation("intelligence_progress_color.json")
                repeatCount = LottieDrawable.INFINITE
                playAnimation()
            }
            t.addView(star, LinearLayout.LayoutParams(dp(24), dp(24)))
            t.addView(text("Analyzing...", 16f, Color.WHITE, true).apply { setPadding(dp(8), 0, 0, 0) })
            c.addView(t)
        } else {
            c.addView(text(m.title, 16f, Color.WHITE, true))
            c.addView(text(m.desc, 13f, 0xFFAAAAAA.toInt(), false).apply {
                maxLines = 3
                setPadding(0, dp(4), 0, 0)
            })
        }
        c.addView(text(time, 12f, 0xFF888888.toInt(), false).apply { setPadding(0, dp(6), 0, 0) })
        row.addView(c, LinearLayout.LayoutParams(0, -2, 1f).apply { marginStart = dp(14) })
        return row
    }

    private fun text(s: String, sp: Float, color: Int, bold: Boolean): TextView = TextView(this).apply {
        text = s
        textSize = sp
        setTextColor(color)
        if (bold) typeface = Typeface.DEFAULT_BOLD
    }

    private fun pill(label: String, onClick: (View) -> Unit): TextView = TextView(this).apply {
        text = label
        textSize = 13f
        setTextColor(Color.WHITE)
        gravity = Gravity.CENTER
        setPadding(dp(14), dp(9), dp(14), dp(9))
        background = GradientDrawable().apply {
            cornerRadius = dp(24).toFloat()
            setColor(0xFF2B2B2D.toInt())
        }
        setOnClickListener(onClick)
    }
}
