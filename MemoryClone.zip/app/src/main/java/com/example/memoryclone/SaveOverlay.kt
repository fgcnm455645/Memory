package com.example.memoryclone

import android.accessibilityservice.AccessibilityService
import android.animation.Animator
import android.animation.AnimatorListenerAdapter
import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.RenderEffect
import android.graphics.RuntimeShader
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.view.ContextThemeWrapper
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.view.animation.LinearInterpolator
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.TextView
import com.airbnb.lottie.LottieAnimationView

/**
 * Full-screen overlay that plays the "Save to Memory" animation over whatever is on screen.
 * - wave: ORIGINAL Samsung AGSL shader (WaveShader), pulls the screenshot down into the icon
 * - icon: ORIGINAL Lottie "app icon 2" with its 3 PNG layers
 * - timing / tint / glow / caption: matched by eye from the screen recording (approximate)
 */
class SaveOverlay(
    private val service: AccessibilityService,
    private val shot: Bitmap,
    private val onDone: () -> Unit
) {
    companion object {
        const val WAVE_MS = 650f
        const val ICON_START = 1250f
        const val ICON_MS = 2000f
        const val TOTAL_MS = 3400f
    }

    private val ctx = ContextThemeWrapper(service, R.style.Theme_Memory)
    private val wm = service.getSystemService(Context.WINDOW_SERVICE) as WindowManager
    private val root = FrameLayout(ctx)
    private val image = ImageView(ctx)
    private val tint = View(ctx)
    private val glow = View(ctx)
    private val icon = LottieAnimationView(ctx)
    private val caption = TextView(ctx)
    private var shader: RuntimeShader? = null
    private var anim: ValueAnimator? = null
    private var added = false
    private var w = 0
    private var h = 0

    private fun seg(ms: Float, a: Float, b: Float): Float = ((ms - a) / (b - a)).coerceIn(0f, 1f)

    fun show() {
        try {
            val b = wm.maximumWindowMetrics.bounds
            w = b.width()
            h = b.height()

            image.scaleType = ImageView.ScaleType.FIT_XY
            image.setImageBitmap(shot)
            root.addView(image, FrameLayout.LayoutParams(-1, -1))

            tint.background = GradientDrawable(
                GradientDrawable.Orientation.TOP_BOTTOM,
                intArrayOf(0xFF8A7BFF.toInt(), 0xFF3F6BE0.toInt(), 0x00000000)
            )
            tint.alpha = 0f
            root.addView(tint, FrameLayout.LayoutParams(-1, -1))

            val cy = h * 0.895f
            val iconSize = (w * 0.30f).toInt()
            val glowSize = (w * 0.95f).toInt()

            glow.alpha = 0f
            glow.background = GradientDrawable().apply {
                gradientType = GradientDrawable.RADIAL_GRADIENT
                gradientRadius = glowSize / 2f
                colors = intArrayOf(0xCCB58CFF.toInt(), 0x00B58CFF)
            }
            root.addView(glow, FrameLayout.LayoutParams(glowSize, glowSize, Gravity.TOP or Gravity.CENTER_HORIZONTAL).apply {
                topMargin = (cy - glowSize / 2f).toInt()
            })

            icon.setImageAssetsFolder("images/")
            icon.setAnimation("memory_app_icon.json")
            icon.progress = 0f
            icon.visibility = View.INVISIBLE
            root.addView(icon, FrameLayout.LayoutParams(iconSize, iconSize, Gravity.TOP or Gravity.CENTER_HORIZONTAL).apply {
                topMargin = (cy - iconSize / 2f).toInt()
            })

            caption.text = "Saved to Memory"
            caption.textSize = 12f
            caption.setTextColor(Color.WHITE)
            caption.typeface = Typeface.DEFAULT_BOLD
            caption.alpha = 0f
            root.addView(caption, FrameLayout.LayoutParams(-2, -2, Gravity.TOP or Gravity.CENTER_HORIZONTAL).apply {
                topMargin = (cy + iconSize * 0.30f).toInt()
            })

            val lp = WindowManager.LayoutParams(
                w, h,
                WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                        WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                        WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                        WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS or
                        WindowManager.LayoutParams.FLAG_HARDWARE_ACCELERATED,
                PixelFormat.TRANSLUCENT
            ).apply {
                gravity = Gravity.TOP or Gravity.START
                layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_ALWAYS
            }
            wm.addView(root, lp)
            added = true

            shader = try { RuntimeShader(WaveShader.SRC) } catch (_: Throwable) { null }

            anim = ValueAnimator.ofFloat(0f, TOTAL_MS).apply {
                duration = TOTAL_MS.toLong()
                interpolator = LinearInterpolator()
                addUpdateListener { update(it.animatedValue as Float) }
                addListener(object : AnimatorListenerAdapter() {
                    override fun onAnimationEnd(animation: Animator) = finish()
                })
                start()
            }
        } catch (_: Throwable) {
            finish()
        }
    }

    private fun update(ms: Float) {
        val p = (ms / WAVE_MS).coerceIn(0f, 1f)
        val sh = shader
        if (sh == null || p <= 0f || p >= 1f) {
            image.setRenderEffect(null)
        } else {
            try {
                sh.setFloatUniform("uRes", w.toFloat(), h.toFloat())
                sh.setFloatUniform("uProgress", p)
                image.setRenderEffect(RenderEffect.createRuntimeShaderEffect(sh, "content"))
            } catch (_: Throwable) {
                shader = null
                image.setRenderEffect(null)
            }
        }
        tint.alpha = 0.55f * seg(ms, 450f, 1100f) * (1f - seg(ms, 1500f, 2800f))
        val inIcon = ms >= ICON_START && ms < ICON_START + ICON_MS
        icon.visibility = if (inIcon) View.VISIBLE else View.INVISIBLE
        icon.progress = seg(ms, ICON_START, ICON_START + ICON_MS)
        glow.alpha = seg(ms, ICON_START, ICON_START + 250f) * (1f - seg(ms, 2600f, 3300f))
        caption.alpha = seg(ms, ICON_START + 100f, ICON_START + 400f) * (1f - seg(ms, 2700f, 3200f))
    }

    private fun finish() {
        anim = null
        if (added) {
            try { wm.removeViewImmediate(root) } catch (_: Throwable) {}
            added = false
        }
        onDone()
    }
}
