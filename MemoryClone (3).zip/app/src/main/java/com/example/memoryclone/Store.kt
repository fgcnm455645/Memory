package com.example.memoryclone

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

/** One saved screenshot ("memory"). Stored as a small JSON file + two JPEGs. */
data class Memory(
    val id: Long,
    var title: String,
    var desc: String,
    val pkg: String,
    var analyzing: Boolean
)

object Store {
    private fun dataFile(ctx: Context) = File(ctx.filesDir, "memories.json")
    private fun shotsDir(ctx: Context) = File(ctx.filesDir, "shots").also { it.mkdirs() }

    fun fullFile(ctx: Context, id: Long) = File(shotsDir(ctx), "$id.jpg")
    fun thumbFile(ctx: Context, id: Long) = File(shotsDir(ctx), "${id}_t.jpg")

    @Synchronized
    fun load(ctx: Context): MutableList<Memory> {
        val out = mutableListOf<Memory>()
        try {
            val f = dataFile(ctx)
            if (!f.exists()) return out
            val arr = JSONArray(f.readText())
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                out.add(
                    Memory(
                        o.getLong("id"), o.getString("title"), o.getString("desc"),
                        o.getString("pkg"), o.getBoolean("analyzing")
                    )
                )
            }
        } catch (_: Throwable) {
        }
        return out
    }

    @Synchronized
    private fun save(ctx: Context, list: List<Memory>) {
        val arr = JSONArray()
        for (m in list) {
            arr.put(
                JSONObject()
                    .put("id", m.id).put("title", m.title).put("desc", m.desc)
                    .put("pkg", m.pkg).put("analyzing", m.analyzing)
            )
        }
        dataFile(ctx).writeText(arr.toString())
    }

    @Synchronized
    fun add(ctx: Context, m: Memory) {
        val list = load(ctx)
        list.add(0, m)
        save(ctx, list)
    }

    @Synchronized
    fun finishAnalysis(ctx: Context, id: Long, title: String, desc: String) {
        val list = load(ctx)
        list.firstOrNull { it.id == id }?.let {
            it.title = title
            it.desc = desc
            it.analyzing = false
        }
        save(ctx, list)
    }
}
