package com.example.memoryclone

import android.content.ComponentName
import android.content.ContentProvider
import android.content.ContentValues
import android.content.Intent
import android.database.Cursor
import android.net.Uri
import android.os.Bundle

/**
 * Samsung "Side key > Double press" action provider.
 *
 * This is the same mechanism the original Samsung Memory app uses (copied from its manifest and
 * from SideButtonProvider in classes2.dex): Samsung Settings finds this provider through the
 * SIDE_BUTTON_SETTINGS intent filter, asks it for the action info with
 * call("sidebutton/getInfo", key) and later starts the returned intent when the side key is
 * double pressed.
 */
class SideButtonProvider : ContentProvider() {

    companion object {
        const val KEY_CAPTURE = "key_memoryclone_capture"
    }

    override fun onCreate(): Boolean = false

    override fun call(method: String, arg: String?, extras: Bundle?): Bundle {
        if (method != "sidebutton/getInfo") {
            throw IllegalArgumentException("Unknown Uri format: $method")
        }
        val result = Bundle()
        val key = extras?.getString("key")
        result.putBoolean("isAvailable", true)
        val intent = Intent()
        if (key == KEY_CAPTURE || key == null) {
            result.putString("title", context!!.resources.getString(R.string.side_button_action_save))
            intent.component = ComponentName(
                "com.example.memoryclone",
                "com.example.memoryclone.TriggerActivity"
            )
            intent.addFlags(Intent.FLAG_ACTIVITY_NO_USER_ACTION)
            result.putInt("intentType", 1)
        }
        result.putString("intentUri", intent.toUri(Intent.URI_INTENT_SCHEME))
        return result
    }

    override fun query(uri: Uri, projection: Array<out String>?, selection: String?, selectionArgs: Array<out String>?, sortOrder: String?): Cursor? = null
    override fun getType(uri: Uri): String? = null
    override fun insert(uri: Uri, values: ContentValues?): Uri? = null
    override fun delete(uri: Uri, selection: String?, selectionArgs: Array<out String>?): Int = -1
    override fun update(uri: Uri, values: ContentValues?, selection: String?, selectionArgs: Array<out String>?): Int = -1
}
