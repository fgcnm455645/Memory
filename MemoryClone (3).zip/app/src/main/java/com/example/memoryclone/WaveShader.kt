package com.example.memoryclone

/** Original AGSL shader from Samsung Memory (classes.dex), unchanged. */
object WaveShader {
    const val SRC = """
            uniform shader content;
            uniform float2 uRes;
            uniform float uProgress;

            float2 distortUV(float2 uv, float p, float aspect) {
                float sq = smoothstep(0.02, 0.29, p) *
                    (1.0 - smoothstep(0.333, 0.947, p));
                float2 sc = float2(1.0 + 0.015 * sq, 1.0 - 0.02 * sq);
                float2 anchor = float2(0.5, 1.0);
                float2 q = float2(uv.x, uv.y - 4.29 / 3200.0 * sq);
                float2 lp = anchor + (q - anchor) / max(sc, float2(0.0001));
                float over = max(p - 0.39, 0.0);
                float amp = smoothstep(0.0, 0.33, p) *
                    exp(-pow(over / 0.098, 1.4));
                float front = 1.5 * p + 11.25 * over * over;
                float2 center = float2(0.5, -0.035);
                float d = length(float2((lp.x - center.x) * aspect, lp.y - center.y));
                float inside = 1.0 - smoothstep(front - 0.15, front + 0.15, d);
                lp -= float2(-0.002, 0.03) * amp * inside;
                float bx = 2.0 * (uv.x - center.x);
                float depth = max(0.3 * (1.0 + 0.4 * bx * bx), 0.001);
                float t = clamp(uv.y / depth, 0.0, 1.0);
                float t2 = t * t;
                float dy = (uv.y - lp.y) * t * (1.25 - 0.25 * t2 * t2);
                lp.y = uv.y - min(dy, 0.9 * uv.y);
                return lp;
            }

            half4 main(float2 p) {
                float2 resolution = max(uRes, float2(1.0));
                float2 uv = p / resolution;
                float progress = clamp(uProgress, 0.0, 1.0);
                float2 source = uv;
                if (progress > 0.0 && progress < 1.0) {
                    source = distortUV(uv, progress, resolution.x / resolution.y);
                }
                return content.eval(clamp(
                    source * resolution, float2(0.5), resolution - float2(0.5)
                ));
            }
        """

    /** Original AGSL "slit glow + particles" shader from Samsung Memory (classes2.dex), unchanged. */
    const val SLIT = """
            uniform float2 iResolution;
            uniform float2 uOrigin;
            uniform float iTime;
            uniform float4 uTracks[9];
            uniform float4 uParticleSeeds[14];
            const float uBrightness = 1.47;
            const float uWidth = 1.15;
            const float uHeight = 0.22;
            const float uSlitWidth = 0.57;
            const float uSlitHeight = 28.3;
            const float uSlitBlur = 0.29;
            uniform float uSlitAlpha;
            const float uGlow = 0.24;
            const float uCoreSize = 0.3;
            const float uBloom = 0.3;
            const float uBloomLength = 0.83;
            const float uBloomHeight = 2.7;
            const float uColorAmount = 1.22;
            const float uWhiteAmount = 0;
            const float uSaturation = 2.13;
            const float uCyanBlur = 2.08;
            const float uBlueBlur = 3;
            const float uLavenderBlur = 2.58;
            const float uPurpleBlur = 2.38;
            uniform float uParticles;
            const float uParticleRange = 0.96;
            const float uParticleHeight = 3;
            const float uParticleSize = 1.23;
            const float uParticleSpeed = 0.34;
            const float uParticleDir = 1;
            const float uParticleAlpha = 1;
            const float uParticleY = -0.03;
            const float3 uCyan = float3(0.486, 0.851, 0.957);
            const float3 uBlue = float3(0.498, 0.651, 0.973);
            const float3 uLavender = float3(0.608, 0.553, 0.973);
            const float3 uPurple = float3(0.773, 0.545, 0.965);
            const float2 uPosition = float2(0.51, 0.9);
            const float uEdgeClear = 1.4;

            float ellipseGlow(float2 p, float2 radius, float softness) {
                float d = length(p / max(radius, float2(0.0001)));
                return exp(-d * d * softness);
            }

            float capsuleGlow(float2 p, float halfLen, float radius, float softness) {
                float2 q = float2(p.x - clamp(p.x, -halfLen, halfLen), p.y);
                float d = length(q) / max(radius, 0.0001);
                return exp(-d * d * softness);
            }

            // Keep the source blur footprint. Apply AE layer growth to light energy,
            // so its existing timing does not compress the blurred color into a capsule.
            float spectrumBand(float2 p, float2 radius, float softness, float blur, float4 track) {
                return ellipseGlow(p, radius, softness) * inversesqrt(blur) *
                    max(track.y, 0.0) * track.z;
            }

            half4 main(float2 fragCoord) {
                float2 uv = (fragCoord - uOrigin) / iResolution;
                float aspect = iResolution.x / iResolution.y;
                float t = iTime;
                float cycleT = 148.0 / 60.0;
                float2 p = uv - uPosition;
                p.x *= aspect;

                float regionBottom = smoothstep(0.985, 0.94, uv.y);
                float regionTop = smoothstep(0.66, 0.73, uv.y);
                float sideClip = smoothstep(0.24, 0.18, abs(p.x));
                float clipMask = regionTop * regionBottom * sideClip;

                float spawnW = 0.105 * uWidth;
                float spawnH = 0.105 * uHeight;

                float slitW = 0.105 * uWidth * uSlitWidth;
                float slitH = 0.0065 * uHeight * uSlitHeight;
                float slitBlur = max(uSlitBlur, 0.2);
                float2 slitP = float2(p.x, p.y);

                // Original 20261026 shader: band centers, blur, and energy normalization.
                float bandBlur = mix(0.75, 1.8, slitBlur);
                float cyanBand = spectrumBand(
                    slitP - float2(-slitW * 0.45, 0.0),
                    float2(slitW * 0.72 * bandBlur * uCyanBlur, slitH * 3.2 * bandBlur * uGlow * uCyanBlur),
                    3.6, uCyanBlur, uTracks[1]);
                float blueBand = spectrumBand(
                    slitP - float2(-slitW * 0.16, 0.0),
                    float2(slitW * 0.62 * bandBlur * uBlueBlur, slitH * 2.7 * bandBlur * uGlow * uBlueBlur),
                    4.0, uBlueBlur, uTracks[2]);
                float lavenderBand = spectrumBand(
                    slitP - float2(slitW * 0.17, 0.0),
                    float2(slitW * 0.62 * bandBlur * uLavenderBlur, slitH * 2.7 * bandBlur * uGlow * uLavenderBlur),
                    4.0, uLavenderBlur, uTracks[3]);
                float purpleBand = spectrumBand(
                    slitP - float2(slitW * 0.47, 0.0),
                    float2(slitW * 0.72 * bandBlur * uPurpleBlur, slitH * 3.2 * bandBlur * uGlow * uPurpleBlur),
                    3.6, uPurpleBlur, uTracks[4]);

                float haloLen = slitW * 1.18 * uBloom * uBloomLength;
                float haloRad = max(slitH * 5.8 * uGlow * uBloom * slitBlur * uBloomHeight, 0.0015);
                float2 coreP = slitP / max(uTracks[0].xy, float2(0.001));
                float slitHalo = capsuleGlow(coreP, haloLen, haloRad, 3.0) * uTracks[0].z;
                float slitCore = ellipseGlow(coreP, float2(slitW * 0.53 * uCoreSize, max(slitH * 0.68 * uCoreSize, 0.0015)), 5.2) * uTracks[0].z;
                float hotCore = ellipseGlow(coreP, float2(slitW * 0.22 * uCoreSize, max(slitH * 0.42 * uCoreSize, 0.0010)), 5.8) * uTracks[0].z;

                float floorGlow = uTracks[0].z * exp(-abs(coreP.y) * 155.0 / max(uBloom * slitBlur * uSlitHeight, 0.1)) * exp(-pow(abs(coreP.x) / max(slitW * 1.45 * uBloom * slitBlur * uBloomLength, 0.0001), 2.0));

                float3 colorCol = float3(0.0);
                colorCol += uCyan * cyanBand * 0.72;
                colorCol += uBlue * blueBand * 0.78;
                colorCol += uLavender * lavenderBand * 0.78;
                colorCol += uPurple * purpleBand * 0.68;
                colorCol += mix(uCyan, uLavender, 0.46) * slitHalo * 0.42;
                colorCol += mix(uBlue, uLavender, 0.55) * floorGlow * 0.25;

                float3 whiteCol = float3(0.0);
                whiteCol += float3(0.76, 0.90, 1.0) * slitCore * 1.65;
                whiteCol += float3(1.0, 0.98, 1.0) * hotCore * 2.5;

                float3 slitCol = (colorCol * uColorAmount + whiteCol * uWhiteAmount) * uSlitAlpha;

                float particleLight = 0.0;
                float cycle = 0.42 / max(uParticleSpeed, 0.2);
                float sizeDiv = 0.0000012 * uParticleSize * uParticleSize;
                for (int i = 0; i < 14; i++) {
                    float4 seed = uParticleSeeds[i];
                    float rx = seed.x;
                    float ry = seed.y;
                    float lifeOffset = seed.z * cycleT;
                    float life = fract((t + lifeOffset) / cycle);
                    float alive = smoothstep(0.0, 0.16, life) * (1.0 - smoothstep(0.42, 1.0, life));
                    float2 spawnPos = float2((rx - 0.5) * spawnW * 2.25 * uParticleRange, -0.012 - ry * spawnH * 0.90 * uParticleHeight);
                    float2 lightPos = float2(spawnPos.x * 0.12, 0.0);
                    float2 starPos = spawnPos + (lightPos - spawnPos) * life * life * uParticleDir;
                    float2 delta = p - starPos - float2(0.0, uParticleY);
                    delta.x *= 1.0 + seed.w * 0.5;
                    float star = exp(-dot(delta, delta) / sizeDiv);
                    particleLight += star * alive;
                }

                float3 particleCol = mix(uCyan, uLavender, 0.5) * particleLight * uParticles * uParticleAlpha * uTracks[5].z * 0.56;
                float3 col = slitCol + particleCol;
                col *= uBrightness * clipMask;
                col = 1.0 - exp(-col * 1.22);
                float luma = dot(col, float3(0.299, 0.587, 0.114));
                col = clamp(mix(float3(luma), col, uSaturation), 0.0, 1.0);
                col *= smoothstep(0.69, 0.76, uv.y);

                float alpha = clamp(pow(max(max(col.r, col.g), col.b), uEdgeClear), 0.0, 1.0);
                // ShaderToy composites col / alpha before limiting the final output.
                // Return that premultiplied light directly; limiting straight RGB first
                // clips bright blue/lavender components and makes the glow duller.
                return half4(half3(col), half(alpha));
            }
        """

    /**
     * Veil: multiplies the screenshot by a colour field measured frame by frame from the original
     * screen recording (dark scrim, cyan/blue light that follows the wave down the screen).
     * The field is stored in assets/veil_atlas.png: 106 tiles of 12x20 RGB, 14 tiles per row.
     */
    const val VEIL = """
            uniform shader content;
            uniform shader atlas;
            uniform float2 uRes;
            uniform float uFrame;
            uniform float uBlend;

            float2 tileOrigin(float f) {
                float row = floor(f / 14.0);
                float col = f - row * 14.0;
                return float2(col * 12.0, row * 20.0);
            }

            half3 mulAt(float f, float2 uv) {
                float2 cell = clamp(uv * float2(12.0, 20.0), float2(0.5, 0.5), float2(11.5, 19.5));
                return atlas.eval(tileOrigin(f) + cell).rgb;
            }

            half4 main(float2 p) {
                half4 c = content.eval(p);
                float2 uv = p / uRes;
                float f0 = floor(uFrame);
                float k = uFrame - f0;
                float f1 = min(f0 + 1.0, 105.0);
                half3 m = mix(mulAt(f0, uv), mulAt(f1, uv), half(k));
                m = mix(half3(0.58824), m, half(uBlend));
                return half4(c.rgb * m * 1.7, c.a);
            }
        """
}
