package com.example.memoryclone

import android.accessibilityservice.AccessibilityService
import android.animation.Animator
import android.animation.AnimatorListenerAdapter
import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.BitmapShader
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.PixelFormat
import android.graphics.RenderEffect
import android.graphics.RuntimeShader
import android.graphics.Shader
import android.graphics.Typeface
import android.view.ContextThemeWrapper
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.view.animation.LinearInterpolator
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.TextView
import com.airbnb.lottie.LottieAnimationView
import java.util.Random
import kotlin.math.pow

/**
 * Full-screen overlay that plays the "Save to Memory" animation over whatever is on screen.
 *
 * Everything below was measured frame by frame from the original screen recording (131762.mp4):
 *  - wave progress p(t): fitted with the ORIGINAL wave shader, starts at 0.28 s, ends at 1.72 s, eased
 *  - screen colour / darkness: veil atlas (assets/veil_atlas.png), 30 fps, multiplied over the screenshot
 *  - slit glow + particles: ORIGINAL shader, strength fitted (about 0.65), on from 1.3 s to 2.45 s
 *  - icon: ORIGINAL Lottie, appears at 1.38 s, leaves at 2.45 s, size and position measured
 * Time t is in seconds from the moment of the save.
 */
class SaveOverlay(
    private val service: AccessibilityService,
    private val shot: Bitmap,
    private val onDone: () -> Unit
) {
    companion object {
        const val TOTAL_S = 3.5f
        const val WAVE_START = 0.28f
        const val WAVE_LEN = 1.44f
        const val WAVE_POW = 1.35f
        const val SLIT_AMOUNT = 0.65f
        const val VEIL_FRAMES = 106
    }

    private val ctx = ContextThemeWrapper(service, R.style.Theme_Memory)
    private val wm = service.getSystemService(Context.WINDOW_SERVICE) as WindowManager
    private val root = FrameLayout(ctx)
    private val image = ImageView(ctx)
    private val slit = SlitView(ctx)
    private val icon = LottieAnimationView(ctx)
    private val caption = TextView(ctx)
    private var wave: RuntimeShader? = null
    private var veil: RuntimeShader? = null
    private var anim: ValueAnimator? = null
    private var added = false
    private var w = 0
    private var h = 0

    private fun seg(t: Float, a: Float, b: Float): Float = ((t - a) / (b - a)).coerceIn(0f, 1f)
    private fun smooth(x: Float): Float = x * x * (3f - 2f * x)

    /** Original Lottie frame (0..120) for a given time: appears at 1.38 s, bump at 2.1-2.25 s, gone at 2.45 s. */
    private fun lottieFrame(t: Float): Float {
        val ts = floatArrayOf(1.30f, 1.40f, 2.10f, 2.25f, 2.30f, 2.45f)
        val fs = floatArrayOf(0f, 12f, 75f, 84f, 93f, 105f)
        if (t <= ts[0]) return 0f
        if (t >= ts[ts.size - 1]) return fs[fs.size - 1]
        for (i in 1 until ts.size) {
            if (t <= ts[i]) {
                val k = (t - ts[i - 1]) / (ts[i] - ts[i - 1])
                return fs[i - 1] + (fs[i] - fs[i - 1]) * k
            }
        }
        return 0f
    }

    fun show() {
        try {
            val b = wm.maximumWindowMetrics.bounds
            w = b.width()
            h = b.height()

            image.scaleType = ImageView.ScaleType.FIT_XY
            image.setImageBitmap(shot)
            root.addView(image, FrameLayout.LayoutParams(-1, -1))

            // slit glow + particles (bottom strip)
            val slitTop = (h * 0.66f).toInt()
            slit.setup(w, h, slitTop)
            root.addView(slit, FrameLayout.LayoutParams(-1, h - slitTop, Gravity.TOP).apply {
                topMargin = slitTop
            })

            // Icon: white square centre at 0.886 H, white square = 0.125 W wide
            val iconSize = (w * 0.34f).toInt()
            val iconCenterY = h * 0.886f + iconSize * 0.124f
            icon.setImageAssetsFolder("images/")
            icon.setAnimation("memory_app_icon.json")
            icon.progress = 0f
            icon.visibility = View.INVISIBLE
            root.addView(icon, FrameLayout.LayoutParams(iconSize, iconSize, Gravity.TOP or Gravity.CENTER_HORIZONTAL).apply {
                topMargin = (iconCenterY - iconSize / 2f).toInt()
            })

            caption.text = "Saved to Memory."
            caption.textSize = 13.5f
            caption.setTextColor(Color.WHITE)
            caption.typeface = Typeface.DEFAULT_BOLD
            caption.setShadowLayer(6f, 0f, 1f, 0x55000000)
            caption.alpha = 0f
            root.addView(caption, FrameLayout.LayoutParams(-2, -2, Gravity.TOP or Gravity.CENTER_HORIZONTAL).apply {
                topMargin = (h * 0.940f - 26f).toInt()
            })

            val lp = WindowManager.LayoutParams(
                w, h,
                WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                        WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                        WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                        WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS or
                        WindowManager.LayoutParams.FLAG_HARDWARE_ACCELERATED,
                PixelFormat.TRANSLUCENT
            ).apply {
                gravity = Gravity.TOP or Gravity.START
                layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_ALWAYS
            }
            wm.addView(root, lp)
            added = true

            wave = try { RuntimeShader(WaveShader.SRC) } catch (_: Throwable) { null }
            veil = try {
                val atlas = BitmapFactory.Options().apply { inScaled = false }.let {
                    service.assets.open("veil_atlas.png").use { s -> BitmapFactory.decodeStream(s, null, it) }
                }
                RuntimeShader(WaveShader.VEIL).also { sh ->
                    val bs = BitmapShader(atlas!!, Shader.TileMode.CLAMP, Shader.TileMode.CLAMP)
                    bs.setFilterMode(BitmapShader.FILTER_MODE_LINEAR)
                    sh.setInputShader("atlas", bs)
                }
            } catch (_: Throwable) { null }

            anim = ValueAnimator.ofFloat(0f, TOTAL_S).apply {
                duration = (TOTAL_S * 1000f).toLong()
                interpolator = LinearInterpolator()
                addUpdateListener { update(it.animatedValue as Float) }
                addListener(object : AnimatorListenerAdapter() {
                    override fun onAnimationEnd(animation: Animator) = finish()
                })
                start()
            }
        } catch (_: Throwable) {
            finish()
        }
    }

    private fun update(t: Float) {
        // 1) wave (original shader) + veil (measured colour field), chained on the screenshot
        val tau = ((t - WAVE_START) / WAVE_LEN).coerceIn(0f, 1f)
        val p = tau.pow(WAVE_POW)
        var effect: RenderEffect? = null
        try {
            val vs = veil
            val ws = wave
            var inner: RenderEffect? = null
            if (ws != null && p > 0f && p < 1f) {
                ws.setFloatUniform("uRes", w.toFloat(), h.toFloat())
                ws.setFloatUniform("uProgress", p)
                inner = RenderEffect.createRuntimeShaderEffect(ws, "content")
            }
            if (vs != null && t < TOTAL_S) {
                vs.setFloatUniform("uRes", w.toFloat(), h.toFloat())
                vs.setFloatUniform("uFrame", (t * 30f).coerceIn(0f, (VEIL_FRAMES - 1).toFloat()))
                vs.setFloatUniform("uBlend", smooth(seg(t, 0f, 0.12f)))
                val outer = RenderEffect.createRuntimeShaderEffect(vs, "content")
                effect = if (inner != null) RenderEffect.createChainEffect(outer, inner) else outer
            } else {
                effect = inner
            }
        } catch (_: Throwable) {
            wave = null
            veil = null
            effect = null
        }
        image.setRenderEffect(effect)

        // 2) slit glow + particles: on at 1.3 s, full by 1.5 s, off by 2.45 s
        val glow = smooth(seg(t, 1.30f, 1.50f)) * (1f - smooth(seg(t, 2.20f, 2.45f)))
        slit.update(glow * SLIT_AMOUNT, glow, t - 1.38f)

        // 3) icon (original Lottie) and caption
        val inIcon = t >= 1.30f && t < 2.46f
        icon.visibility = if (inIcon) View.VISIBLE else View.INVISIBLE
        icon.progress = (lottieFrame(t) / 120f).coerceIn(0f, 1f)
        caption.alpha = seg(t, 1.35f, 1.50f) * (1f - seg(t, 2.30f, 2.50f))
    }

    private fun finish() {
        anim = null
        if (added) {
            try { wm.removeViewImmediate(root) } catch (_: Throwable) {}
            added = false
        }
        onDone()
    }

    /** Runs the ORIGINAL slit-glow + particle shader on the bottom strip of the screen. */
    private class SlitView(context: Context) : View(context) {
        private var shader: RuntimeShader? = null
        private val paint = Paint()
        private var fullW = 0f
        private var fullH = 0f
        private var top = 0f
        private val tracks = FloatArray(36)
        private val seeds = FloatArray(56)
        private var time = 0f
        private var on = false

        fun setup(w: Int, h: Int, topPx: Int) {
            fullW = w.toFloat()
            fullH = h.toFloat()
            top = topPx.toFloat()
            val rnd = Random(7)
            for (i in seeds.indices) seeds[i] = rnd.nextFloat()
            shader = try { RuntimeShader(WaveShader.SLIT) } catch (_: Throwable) { null }
            paint.shader = shader
        }

        fun update(slitAmount: Float, particleAmount: Float, t: Float) {
            on = slitAmount > 0.002f && shader != null
            time = t
            tracks.fill(0f)
            tracks[0] = 1f; tracks[1] = 1f; tracks[2] = slitAmount
            for (i in 1..4) { tracks[i * 4 + 1] = 1f; tracks[i * 4 + 2] = slitAmount }
            tracks[5 * 4 + 2] = particleAmount
            visibility = if (on) VISIBLE else INVISIBLE
            if (on) invalidate()
        }

        override fun onDraw(canvas: Canvas) {
            val sh = shader ?: return
            if (!on) return
            try {
                sh.setFloatUniform("iResolution", fullW, fullH)
                sh.setFloatUniform("uOrigin", 0f, -top)
                sh.setFloatUniform("iTime", time.coerceAtLeast(0f))
                sh.setFloatUniform("uTracks", tracks)
                sh.setFloatUniform("uParticleSeeds", seeds)
                sh.setFloatUniform("uSlitAlpha", 1f)
                sh.setFloatUniform("uParticles", 1f)
                canvas.drawRect(0f, 0f, width.toFloat(), height.toFloat(), paint)
            } catch (_: Throwable) {
                shader = null
            }
        }
    }
}
