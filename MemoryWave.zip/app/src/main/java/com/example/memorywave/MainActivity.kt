package com.example.memorywave

import android.animation.ValueAnimator
import android.graphics.Color
import android.graphics.RenderEffect
import android.graphics.RuntimeShader
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.animation.LinearInterpolator
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import com.airbnb.lottie.LottieAnimationView

/**
 * Part 0b - "Save to Memory" wave test.
 *
 * - The wave (screen squeeze + ripple that pulls the screen down into the bottom icon)
 *   uses the ORIGINAL AGSL shader found in Samsung Memory's classes.dex, unchanged.
 * - The bottom icon uses the ORIGINAL "app icon 2" Lottie + its 3 PNG layers.
 * - Timing of the wave (about 650 ms) and the blue glow / caption are matched by eye
 *   from the screen recording, so they are approximate. Use Speed to compare.
 */
class MainActivity : AppCompatActivity() {

    companion object {
        const val SHADER = """
            uniform shader content;
            uniform float2 uRes;
            uniform float uProgress;

            float2 distortUV(float2 uv, float p, float aspect) {
                float sq = smoothstep(0.02, 0.29, p) *
                    (1.0 - smoothstep(0.333, 0.947, p));
                float2 sc = float2(1.0 + 0.015 * sq, 1.0 - 0.02 * sq);
                float2 anchor = float2(0.5, 1.0);
                float2 q = float2(uv.x, uv.y - 4.29 / 3200.0 * sq);
                float2 lp = anchor + (q - anchor) / max(sc, float2(0.0001));
                float over = max(p - 0.39, 0.0);
                float amp = smoothstep(0.0, 0.33, p) *
                    exp(-pow(over / 0.098, 1.4));
                float front = 1.5 * p + 11.25 * over * over;
                float2 center = float2(0.5, -0.035);
                float d = length(float2((lp.x - center.x) * aspect, lp.y - center.y));
                float inside = 1.0 - smoothstep(front - 0.15, front + 0.15, d);
                lp -= float2(-0.002, 0.03) * amp * inside;
                float bx = 2.0 * (uv.x - center.x);
                float depth = max(0.3 * (1.0 + 0.4 * bx * bx), 0.001);
                float t = clamp(uv.y / depth, 0.0, 1.0);
                float t2 = t * t;
                float dy = (uv.y - lp.y) * t * (1.25 - 0.25 * t2 * t2);
                lp.y = uv.y - min(dy, 0.9 * uv.y);
                return lp;
            }

            half4 main(float2 p) {
                float2 resolution = max(uRes, float2(1.0));
                float2 uv = p / resolution;
                float progress = clamp(uProgress, 0.0, 1.0);
                float2 source = uv;
                if (progress > 0.0 && progress < 1.0) {
                    source = distortUV(uv, progress, resolution.x / resolution.y);
                }
                return content.eval(clamp(
                    source * resolution, float2(0.5), resolution - float2(0.5)
                ));
            }
        """

        const val WAVE_MS = 650f        // length of the shader progress 0..1 (estimated from video)
        const val ICON_START = 1250f    // icon Lottie start (estimated from video)
        const val ICON_MS = 2000f       // icon Lottie is 120 frames at 60 fps
        const val TOTAL_MS = 3400f
    }

    private lateinit var root: FrameLayout
    private lateinit var stage: FrameLayout
    private lateinit var image: ImageView
    private lateinit var tint: View
    private lateinit var glow: View
    private lateinit var icon: LottieAnimationView
    private lateinit var caption: TextView
    private lateinit var speedBtn: TextView

    private val shader by lazy { RuntimeShader(SHADER) }
    private var anim: ValueAnimator? = null
    private var speedIdx = 0
    private val speeds = floatArrayOf(1f, 0.5f, 0.25f)

    private val pickImage = registerForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) image.setImageURI(uri)
    }

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        WindowCompat.setDecorFitsSystemWindows(window, false)
        WindowInsetsControllerCompat(window, window.decorView).apply {
            hide(WindowInsetsCompat.Type.systemBars())
            systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        }

        root = FrameLayout(this).apply { setBackgroundColor(Color.BLACK) }
        stage = FrameLayout(this)
        stage.setOnClickListener { play() }

        image = ImageView(this).apply {
            scaleType = ImageView.ScaleType.CENTER_CROP
            setImageResource(R.drawable.sample_home)
        }
        stage.addView(image, FrameLayout.LayoutParams(-1, -1))

        tint = View(this).apply {
            background = GradientDrawable(
                GradientDrawable.Orientation.TOP_BOTTOM,
                intArrayOf(0xFF8A7BFF.toInt(), 0xFF3F6BE0.toInt(), 0x00000000)
            )
            alpha = 0f
        }
        stage.addView(tint, FrameLayout.LayoutParams(-1, -1))

        glow = View(this).apply { alpha = 0f }
        stage.addView(glow, FrameLayout.LayoutParams(1, 1))

        icon = LottieAnimationView(this).apply {
            setAnimation("memory_app_icon.json")
            progress = 0f
            alpha = 0f
        }
        stage.addView(icon, FrameLayout.LayoutParams(1, 1))

        caption = TextView(this).apply {
            text = "Saved to Memory"
            textSize = 12f
            setTextColor(Color.WHITE)
            typeface = Typeface.DEFAULT_BOLD
            alpha = 0f
        }
        stage.addView(caption, FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.WRAP_CONTENT, FrameLayout.LayoutParams.WRAP_CONTENT))

        root.addView(stage, FrameLayout.LayoutParams(-1, -1))

        // Controls (outside the stage so the wave does not distort them)
        val controls = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
        }
        speedBtn = pill("Speed: 1x") {
            speedIdx = (speedIdx + 1) % speeds.size
            speedBtn.text = "Speed: " + (if (speedIdx == 0) "1x" else if (speedIdx == 1) "0.5x" else "0.25x")
            play()
        }
        for (b in listOf(pill("Play") { play() }, pill("Pick image") { pickImage.launch("image/*") }, speedBtn)) {
            controls.addView(b, LinearLayout.LayoutParams(-2, -2).apply {
                marginStart = dp(5); marginEnd = dp(5)
            })
        }
        root.addView(controls, FrameLayout.LayoutParams(-2, -2, Gravity.TOP or Gravity.CENTER_HORIZONTAL).apply {
            topMargin = dp(40)
        })

        setContentView(root)
        root.post { layoutOverlays(); update(0f) }
    }

    private fun layoutOverlays() {
        val w = stage.width
        val h = stage.height
        val cy = h * 0.895f
        val iconSize = (w * 0.30f).toInt()
        icon.layoutParams = FrameLayout.LayoutParams(iconSize, iconSize, Gravity.TOP or Gravity.CENTER_HORIZONTAL).apply {
            topMargin = (cy - iconSize / 2f).toInt()
        }
        val glowSize = (w * 0.95f).toInt()
        glow.background = GradientDrawable().apply {
            gradientType = GradientDrawable.RADIAL_GRADIENT
            gradientRadius = glowSize / 2f
            colors = intArrayOf(0xCCB58CFF.toInt(), 0x00B58CFF)
        }
        glow.layoutParams = FrameLayout.LayoutParams(glowSize, glowSize, Gravity.TOP or Gravity.CENTER_HORIZONTAL).apply {
            topMargin = (cy - glowSize / 2f).toInt()
        }
        caption.layoutParams = FrameLayout.LayoutParams(-2, -2, Gravity.TOP or Gravity.CENTER_HORIZONTAL).apply {
            topMargin = (cy + iconSize * 0.30f).toInt()
        }
    }

    private fun seg(ms: Float, a: Float, b: Float): Float = ((ms - a) / (b - a)).coerceIn(0f, 1f)

    private fun update(ms: Float) {
        // 1) the wave: original shader, progress 0..1
        val p = (ms / WAVE_MS).coerceIn(0f, 1f)
        if (p <= 0f || p >= 1f || image.width == 0) {
            image.setRenderEffect(null)
        } else {
            shader.setFloatUniform("uRes", image.width.toFloat(), image.height.toFloat())
            shader.setFloatUniform("uProgress", p)
            image.setRenderEffect(RenderEffect.createRuntimeShaderEffect(shader, "content"))
        }
        // 2) blue-violet tint over the screen (approximate)
        tint.alpha = 0.55f * seg(ms, 450f, 1100f) * (1f - seg(ms, 1500f, 2800f))
        // 3) icon + glow + caption (icon = original Lottie, driven by the same timeline)
        val inIcon = ms >= ICON_START && ms < ICON_START + ICON_MS
        icon.alpha = if (inIcon) 1f else 0f
        icon.progress = seg(ms, ICON_START, ICON_START + ICON_MS)
        glow.alpha = seg(ms, ICON_START, ICON_START + 250f) * (1f - seg(ms, 2600f, 3300f))
        caption.alpha = seg(ms, ICON_START + 100f, ICON_START + 400f) * (1f - seg(ms, 2700f, 3200f))
    }

    private fun play() {
        anim?.cancel()
        update(0f)
        val total = TOTAL_MS / speeds[speedIdx]
        anim = ValueAnimator.ofFloat(0f, TOTAL_MS).apply {
            duration = total.toLong()
            interpolator = LinearInterpolator()
            addUpdateListener { update(it.animatedValue as Float) }
            start()
        }
    }

    private fun pill(text: String, onClick: (View) -> Unit): TextView {
        return TextView(this).apply {
            this.text = text
            textSize = 13f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            setPadding(dp(14), dp(9), dp(14), dp(9))
            background = GradientDrawable().apply {
                cornerRadius = dp(24).toFloat()
                setColor(0xCC2B2B2D.toInt())
            }
            setOnClickListener(onClick)
        }
    }
}
